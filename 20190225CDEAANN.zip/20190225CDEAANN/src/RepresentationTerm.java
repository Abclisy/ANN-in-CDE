
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Representation")
public class RepresentationTerm {
	
	private String Long_Name;

	/**
	 * @return the long_Name
	 */
	public String getLong_Name() {
		//replace("\n,r", "").replace(" ","").replace("\t","").
		Long_Name= Long_Name.replace("\n","");//li
		return Long_Name;
	}

	/**
	 * @param long_Name the long_Name to set
	 */
	@XmlElement(name="LongName")
	public void setLong_Name(String long_Name) {
		Long_Name = long_Name;
	}

}
