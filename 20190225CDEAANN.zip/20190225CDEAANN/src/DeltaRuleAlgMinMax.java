import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

//modified by lisy - into max & min example
/**
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 * <p>
 * Company: USC
 * </p>
 * 
 * @author Jingshan Huang
 * @version 1.0
 */

public class DeltaRuleAlgMinMax {
	double target = 1;
	static String simVecMatrix[][] = new String[1233][2]; // each cell is a string (e.g. "0.85#0.27#0.56"), recording
	static String simMatrixComp[][];														// the similarity values for 2 concepts in 3 dimensions
	double justnow=0;													// (name, property, and ancestor)
	public double[][] simMatrix; // similarity matrix recalculated using the learned weights
	public int iterationTimes = 10; // how many iterations in running Delta Rule algorithm, will try 10, 15, 20, 30,
									// 50, 80, 100, 200, 500, 1000, 1500, 2500, and 5000.
	public double learningRate = 0.05; // will try 0.05, 0.1, and 0.2
	public double w1 = 1.0 / 6, w2 = 1.0 / 6, w3 = 1.0 / 6, w4 = 1.0 / 6, w5 = 1.0 / 6, w6 = 1.0 / 6; // initialize																	// property, and

	//public DeltaRule(String[][] matrix) {
	public DeltaRuleAlgMinMax() {
		gradientDescent();
	}

	public static void main(String[] args) throws FileNotFoundException {

		FileOutputStream f = new FileOutputStream("logMinMax.txt");
		System.setOut(new PrintStream(f)); 

		System.out.println("getSimMatrix()...");
		simMatrixComp = getSimMatrix();

		System.out.println("finish getSimMatrix()");

		DeltaRuleAlgMinMax deltarule = new DeltaRuleAlgMinMax();

	}

	private static String[][] getSimMatrix() {
		System.out.println("Started");
		// CDEParser CDEAANN;
		CDEParserGetMatrix.outputCurrentTime("1. Start parsing xml files --- ");
		CDEParserGetMatrix.getXmlFiles();
		if (CDEParserGetMatrix.XMLFiles.isEmpty()) {
			System.err.println("No XML Files located");
		}
		for (String s : CDEParserGetMatrix.XMLFiles) {
			System.out.println("the xml files are: " + s);
			String file_Name = new String(s);
			CDEParserGetMatrix.outputCurrentTime("Now parsing file:: " + file_Name);
			CDEParserGetMatrix.generateXML(file_Name);
		}
		// String matrix[][]=new String[1233][2];
		// get similarity matrix with 6 aspects of similarity
		// li sCDESimMatrix get Similarity
		double s1, s2, s3, s4, s5, s6;

		for (int i = 1; i <= 1232; i = i + 1) {
			System.out.println("i="+i);
			for (int j = 1; j <= 1232; j = j + 1) {
				String SameCls="0";
				//System.out.println("Comparing: " + CDEParserGetMatrix.CDEMatrix[1][i]+" and " +CDEParserGetMatrix.CDEMatrix[1][j]);

				//they all belongs to organize class
				/*
				if(CDEParserGetMatrix.CDEMatrix[7][i].equals(CDEParserGetMatrix.CDEMatrix[7][j])&&CDEParserGetMatrix.CDEMatrix[7][j].equals("Organization")) {
					SameCls="1";
				}
				*/
				//s calculation: letter by letter
				s1 = getStringSim(CDEParserGetMatrix.CDEMatrix[1][i],CDEParserGetMatrix.CDEMatrix[1][j]);
				s2 = getStringSim(CDEParserGetMatrix.CDEMatrix[2][i],CDEParserGetMatrix.CDEMatrix[2][j]);
				s3 = getStringSim(CDEParserGetMatrix.CDEMatrix[3][i],CDEParserGetMatrix.CDEMatrix[3][j]);
				s4 = getStringSim(CDEParserGetMatrix.CDEMatrix[4][i],CDEParserGetMatrix.CDEMatrix[4][j]);
				s5 = getStringSim(CDEParserGetMatrix.CDEMatrix[5][i],CDEParserGetMatrix.CDEMatrix[6][j]);
				s6 = getStringSim(CDEParserGetMatrix.CDEMatrix[6][i],CDEParserGetMatrix.CDEMatrix[6][j]);
				
				/*
				if(SameCls.equals("1")) {
					System.out.println("making the s1#s2#s3#s4#s5#s6 matrix");
					System.out.println("s1#s2#s3#s4#s5#s6= "+s1 + "#" + s2 + "#" + s3 + "#" + s4 + "#" + s5 + "#" + s6);
					System.out.println("i="+i+"; j="+j);

				}
				*/
				//System.out.println("i="+i);
				/*
				DecimalFormat df = new DecimalFormat("0.00");
				s1 = Double.parseDouble(df.format(s1));
				s2 = Double.parseDouble(df.format(s2));
				s3 = Double.parseDouble(df.format(s3));
				s4 = Double.parseDouble(df.format(s4));
				s5 = Double.parseDouble(df.format(s5));
				s6 = Double.parseDouble(df.format(s6));
				*/
				
				

				CDEParserGetMatrix.CDESimMatrix[i][j] = (s1 + "#" + s2 + "#" + s3 + "#" + s4 + "#" + s5 + "#" + s6);
			}
		}
		return CDEParserGetMatrix.CDESimMatrix;
	}

	private static double getStringSim(String cde1, String cde2) {
	 	   //System.out.println("Begin processing two cde property-----------");
			double s;
			
			double max=0;
			List<Integer> delListi = new ArrayList<Integer>();
			delListi.add(0);
			List<Integer> delListj = new ArrayList<Integer>();
			delListj.add(0);
			//initialize i
			int tempDeli=0, tempDelj=0;	
			int match=0;
			
			String[] arr1=cde1.split("[^a-zA-Z0-9]+"); 
	        String[] arr2=cde2.split("[^a-zA-Z0-9]+"); 

	        List<String> cde1L=Arrays.asList(arr1);
	        List<String> cde2L=Arrays.asList(arr2);
			int smallerSize=cde1L.size()<cde2L.size()?cde1L.size():cde2L.size();
	        
			Double[][] wordSimMatrix=new Double[cde1L.size()+1][cde2L.size()+1];
			
			//arrange the threshold of similarity
			double threshold=0.5;
			
			//Matrix generate
			for(int i = 1; i <= cde1L.size(); i++) {
				for(int j = 1; j <= cde2L.size(); j++) {
		    		double d;
		    		double l;
					d = CDEParserGetMatrix.StringEditDistance.getDistance(cde1, cde2);
					l = (cde1.length() > cde2.length())
							? cde1.length()
							: cde2.length();
		        	s=1-d/l;
					wordSimMatrix[i][j]=s;
				}
			}
			
	       //same cde
	       if(cde1.equals(cde2)) {
	    	   s=1;
	    	   
	    	   //verify cde1 and cde2 are the same
	    	   //System.out.println("SameCde:cde1-"+cde1+" and "+"cde2-"+cde2);
	    	   //System.out.println("s="+s);
	    	   
	       //not same cde
	       }else {
	    	   //have the iteration times with the smaller s
	    	   for(int n = 1; n <= smallerSize; n++) {
	    		   //begin the search in wordSmMatrix[][]
	    		   for(int i=1;i<=cde1L.size();i++) {
	    			   for(int j=1;j<=cde2L.size();j++) {
	    				   //will not take the rol and col which have been picked up into account
	    				   for(int k=0;k<=delListi.size()-1;k++) {
	    					   //if this col and col have been picked up before
	    					   if(i==delListi.indexOf(k)&&j==delListj.indexOf(k)) {
	    					   //if this col and col havn't been picked up before
	    					   }else {
	    						   //find the max num
	    						   if(wordSimMatrix[i][j]>max) {
	    							   max=wordSimMatrix[i][j];
	    							   //System.out.println("max="+max);
	    							   tempDeli=i;
	    							   tempDelj=j;
	    						   }
	    					   }
	    				   }
	    			   }
	    		   }
	    		   //after find the max num
	    		   delListi.add(tempDeli);
	    		   delListj.add(tempDelj);
	    		   if(max>=threshold) {
	    			   match++;
	    		   }
	    	   }
	    	   
	    	   s=match/smallerSize;
	   			
	    	   //verify cde1 and cde2 are not the same
	    	   //System.out.println("NotSameCde:cde1-"+cde1+" and "+"cde2-"+cde2);
	    	   //System.out.println("s="+s);
	       }

	  	   //System.out.println("Finish processing two cde property-----------");
			return s;
	}
	
	public void gradientDescent() {
		double deltaw1, deltaw2, deltaw3, deltaw4, deltaw5, deltaw6;
		double error = 0; 

		for (int i = 1; i <= iterationTimes; i++) {
			
			System.out.println("iterationTimes: "+i);
			
			deltaw1 = 0;
			deltaw2 = 0;
			deltaw3 = 0;
			deltaw4 = 0;
			deltaw5 = 0;
			deltaw6 = 0;
			
			double sCls1 = 0, sCls2 = 0, sCls3 = 0, sCls4 = 0, sCls5 = 0, sCls6 = 0, sCls = 0; // input values to our
																								// ANNs
			double sMin1 = 0, sMin2 = 0, sMin3 = 0, sMin4 = 0, sMin5 = 0, sMin6 = 0, sMin = 0; // input values to our
																								// ANNs
			double sOtherCls1 = 0, sOtherCls2 = 0, sOtherCls3 = 0, sOtherCls4 = 0, sOtherCls5 = 0, sOtherCls6 = 0,
					sOtherCls = 0; // input values to our ANNs
			double sMax1 = 0, sMax2 = 0, sMax3 = 0, sMax4 = 0, sMax5 = 0, sMax6 = 0, sMax = 0;

			error = 0;

			List trainClsList = trainCls();
			//System.out.println(trainClsList.size());

			for (int n = 0; n <= (trainClsList.size() - 1); n++) {
				int samenum = 0;
				int firstEleFromClsNo = 0;
				boolean notHavFirseElmtNo = true;
				boolean notHavFirstSim = true;

				deltaw1=0;
				deltaw2=0;
				deltaw3=0;
				deltaw4=0;
				deltaw5=0;
				deltaw6=0;
				//System.out.println("Start class " + (n+1)+":" + trainClsList.get(n));
				
				for (int k=1;k<=1232;k++) {
					if (trainClsList.get(n).equals(CDEParserGetMatrix.CDEMatrix[7][k])) {
						if (notHavFirseElmtNo == true) {
							firstEleFromClsNo = k;
							notHavFirseElmtNo = false;
						}
					}
				}
				
				for (int j = 1; j <= 1232; j++) {

					// Similarity from this class
					if (trainClsList.get(n).equals(CDEParserGetMatrix.CDEMatrix[7][j])) {
						
					if (j==firstEleFromClsNo) {
							
					} else {
						List oneCdeSfromCls = getSimilarity(firstEleFromClsNo, j);
						sCls1 = ((Double) oneCdeSfromCls.get(0)).doubleValue();
						sCls2 = ((Double) oneCdeSfromCls.get(1)).doubleValue(); 
						sCls3 = ((Double) oneCdeSfromCls.get(2)).doubleValue();
						sCls4 = ((Double) oneCdeSfromCls.get(3)).doubleValue();
						sCls5 = ((Double) oneCdeSfromCls.get(4)).doubleValue();
						sCls6 = ((Double) oneCdeSfromCls.get(5)).doubleValue();
						sCls = sCls1 * w1 + sCls2 * w2 + sCls3 * w3 + sCls4 * w4 + sCls5 * w5 + sCls6 * w6;
						if (notHavFirstSim == true) {
							sMin = sCls;
							sMin1 = sCls1;
							sMin2 = sCls2;
							sMin3 = sCls3;
							sMin4 = sCls4;
							sMin5 = sCls5;
							sMin6 = sCls6;
							//System.out.println("sMinF= "+sMin);
								
							notHavFirstSim = false;
						} else {
							sMin = sCls < sMin ? sCls : sMin;
							sMin1 = sCls < sMin ? sCls1 : sMin1;
							sMin2 = sCls < sMin ? sCls2 : sMin2;
							sMin3 = sCls < sMin ? sCls3 : sMin3;
							sMin4 = sCls < sMin ? sCls4 : sMin4;
							sMin5 = sCls < sMin ? sCls5 : sMin5;
							sMin6 = sCls < sMin ? sCls6 : sMin6;
						}
					}
						samenum++;

						// Similarity from other classes
					} else {
						List oneCdeSfromOtherCls = getSimilarity(firstEleFromClsNo, j);
						sOtherCls1 = ((Double) oneCdeSfromOtherCls.get(0)).doubleValue();
						sOtherCls2 = ((Double) oneCdeSfromOtherCls.get(1)).doubleValue(); 
						sOtherCls3 = ((Double) oneCdeSfromOtherCls.get(2)).doubleValue();
						sOtherCls4 = ((Double) oneCdeSfromOtherCls.get(3)).doubleValue();
						sOtherCls5 = ((Double) oneCdeSfromOtherCls.get(4)).doubleValue();
						sOtherCls6 = ((Double) oneCdeSfromOtherCls.get(5)).doubleValue();
						sOtherCls = sOtherCls1 * w1 + sOtherCls2 * w2 + sOtherCls3 * w3 + sOtherCls4 * w4 + sOtherCls5 * w5 + sOtherCls6 * w6;
						
						sMax = sOtherCls > sMax ? sOtherCls : sMax;
						sMax1 = sOtherCls > sMax ? sOtherCls1 : sMax1;
						sMax2 = sOtherCls > sMax ? sOtherCls2 : sMax2;
						sMax3 = sOtherCls > sMax ? sOtherCls3 : sMax3;
						sMax4 = sOtherCls > sMax ? sOtherCls4 : sMax4;
						sMax5 = sOtherCls > sMax ? sOtherCls5 : sMax5;
						sMax6 = sOtherCls > sMax ? sOtherCls6 : sMax6;
						
						//System.out.println("sMax= "+sMax);
					}

				}

				System.out.println("sMin: " + sMin);
				System.out.println("sMax: " + sMax);
				
				deltaw1 = learningRate * (target - (sMin - sMax) / sMin) * sMin1;
				deltaw2 = learningRate * (target - (sMin - sMax) / sMin) * sMin2;
				deltaw3 = learningRate * (target - (sMin - sMax) / sMin) * sMin3;
				deltaw4 = learningRate * (target - (sMin - sMax) / sMin) * sMin4;
				deltaw5 = learningRate * (target - (sMin - sMax) / sMin) * sMin5;
				deltaw6 = learningRate * (target - (sMin - sMax) / sMin) * sMin6;
				
				w1 += deltaw1;
				w2 += deltaw2;
				w3 += deltaw3;
				w4 += deltaw4;
				w5 += deltaw5;
				w6 += deltaw6;
				
				error+=(target - (sMin - sMax) / sMin)*(target - (sMin - sMax) / sMin)/2;

				//System.out.println("Finish class " + (n+1)+":" + trainClsList.get(n));

				System.out.println("should be close to zero : sMax / sMin: "+ (sMax / sMin));
			}
				//System.out.println("sMin>sMax: " + (sMin>sMax));
				//System.out.println("(sMin - sMax) / sMin: "+(sMin - sMax) / sMin);
				
				System.out.println("Difference: "+(justnow-(sMax / sMin)));
				justnow=(sMax / sMin);// between this and sMax / sMin and sMax / sMin just now
				
				System.out.println("should be close to zero : sMax / sMin: "+ (sMax / sMin));
				



			// normalize the weights so that they sum to 1
			double tmp = w1 + w2 + w3 + w4 + w5 + w6;
			w1 /= tmp;
			w2 /= tmp;
			w3 /= tmp;
			w4 /= tmp;
			w5 /= tmp;
			w6 /= tmp;

			System.out.println("error: " + error);
/*
			System.out.println("w1: " + w1);
			System.out.println("w2: " + w2);
			System.out.println("w3: " + w3);
			System.out.println("w4: " + w4);
			System.out.println("w5: " + w5);
			System.out.println("w6: " + w6);
			System.out.println("iterationTimes finish: "+i);*/
		}

		System.out.println("error: " + error);

		System.out.println("w1: " + w1);
		System.out.println("w2: " + w2);
		System.out.println("w3: " + w3);
		System.out.println("w4: " + w4);
		System.out.println("w5: " + w5);
		System.out.println("w6: " + w6);
	}

	public List getSimilarity(int i, int j) {
		List sim = new ArrayList();
		String sValue = new String();
		String tmp1 = new String();
		String tmp2 = new String();
		String tmp3 = new String();
		String tmp4 = new String();
		String tmp5 = new String();
		String tmp6 = new String();
		int ind;
		 
		sValue = ((String) simMatrixComp[i][j]).trim();
		
		ind = sValue.indexOf("#");
		tmp1 = sValue.substring(0, ind);
		sValue = sValue.substring(ind + 1);

		ind = sValue.indexOf("#");
		tmp2 = sValue.substring(0, ind);
		sValue = sValue.substring(ind + 1);

		ind = sValue.indexOf("#");
		tmp3 = sValue.substring(0, ind);
		sValue = sValue.substring(ind + 1);

		ind = sValue.indexOf("#");
		tmp4 = sValue.substring(0, ind);
		sValue = sValue.substring(ind + 1);

		ind = sValue.indexOf("#");
		tmp5 = sValue.substring(0, ind);

		tmp6 = sValue.substring(ind + 1);

		sim.add(new Double(tmp1));
		sim.add(new Double(tmp2));
		sim.add(new Double(tmp3));
		sim.add(new Double(tmp4));
		sim.add(new Double(tmp5));
		sim.add(new Double(tmp6));

		return sim;
	}

	public static List<String> trainCls() {
		List<String> trainClsList = new ArrayList<String>(); // list of classes contain more than one CDEs
		trainClsList.add("PerformedClinicalResult");
		trainClsList.add("PerformedDiagnosis");
		trainClsList.add("PerformedObservation");
		trainClsList.add("PerformedObservationResult");
		trainClsList.add("PerformedSubstanceAdministration");
		trainClsList.add("PerformedProcedure");
		trainClsList.add("MaterialName");
		trainClsList.add("TargetAnatomicSite");
		trainClsList.add("PerformedClinicalInterpretation");
		trainClsList.add("DefinedProcedure");
		trainClsList.add("DefinedObservation");
		trainClsList.add("Person");
		trainClsList.add("Organization");
		trainClsList.add("PerformedMedicalConditionResult");
		
		trainClsList.add("DefinedSubstanceAdministration");
		trainClsList.add("ReferenceResult");
		trainClsList.add("SubstanceExtractionAdministrationRelationship");
		trainClsList.add("BiologicEntityIdentifier");
		trainClsList.add("BiologicEntity");
		trainClsList.add("Product");
		trainClsList.add("Animal");
		trainClsList.add("OrganizationIdentifier");
		trainClsList.add("PerformedLesionDescription");
		trainClsList.add("HealthCareFacility");
		trainClsList.add("PerformedProductTransport");
		trainClsList.add("DefinedMaterialProcessStep");
		trainClsList.add("SubjectIdentifier");
		trainClsList.add("PerformedMedicalCondition");
		trainClsList.add("PerformedSubstanceExtraction");
		trainClsList.add("PerformedStudySubjectMilestone");
		trainClsList.add("PerformedMaterialProcessStep");
		trainClsList.add("PerformedAdministrativeActivity");
		trainClsList.add("Performer");
		trainClsList.add("AssociatedBiologicEntity");
		trainClsList.add("PerformedMaterialStorage");
		trainClsList.add("Specimen");
		trainClsList.add("DefinedMaterialStorage");
		trainClsList.add("AdverseEvent");
		trainClsList.add("StudySitePersonnel");
		trainClsList.add("DocumentIdentifier");
		trainClsList.add("MaterialIdentifier");
		trainClsList.add("DefinedActivity");
		trainClsList.add("PerformedSpecimenCollection");
		trainClsList.add("PerformedImaging");

		return trainClsList;
	}

}
