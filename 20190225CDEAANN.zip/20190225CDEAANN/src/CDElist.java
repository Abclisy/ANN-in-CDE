
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;





@XmlRootElement(name="DataElementsList")
public class CDElist {
	@XmlElement(name="DataElement")
    private List<CDE>myDataEle;
	
	public List<CDE> getPhoneNumber() {
        if (myDataEle==null) {
        	System.out.println("new number created");
        	myDataEle=new ArrayList<CDE>();
        }
        return this.myDataEle;
    }

}
