
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ALTERNATENAMELIST")
public class AlternateNames {
	
	@XmlElement(name="ALTERNATENAMELIST_ITEM")
    private List<AlterListItem>mylist;
	
	/**
	 * @return the aNL
	 */
	public List<AlterListItem> getANL() {
        if (mylist==null) {
        	System.out.println("new AlterListItem created");
        	mylist=new ArrayList<AlterListItem>();
        }
        return this.mylist;
    }

}
