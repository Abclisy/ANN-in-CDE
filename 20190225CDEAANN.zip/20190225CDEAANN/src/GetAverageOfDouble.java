import java.util.*;

public class GetAverageOfDouble{
   public static void main( String args[] ) {
       
    List<Double> marks = new ArrayList<Double>();
    marks.add(5.0);
    marks.add(3.0);
    marks.add(1.0);
       
   System.out.println("Average:"+calculateAverage(marks));
   }     
   
   private static double calculateAverage(List <Double> marks) {
	  Double sum = 0.0;
	  if(!marks.isEmpty()) {
	    for (Double mark : marks) {
	        sum += mark;
	    }
	    return sum.doubleValue() / marks.size();
	  }
	  return sum;
   }
}