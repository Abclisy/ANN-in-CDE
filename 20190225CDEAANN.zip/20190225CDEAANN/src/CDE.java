
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="DataElement")
public class CDE {
	
	private String Public_ID;
	private String Pref_Def;
	private String Long_Name;
	private String Context_Name;
	private int id;
	private AlternateNames myANL;
	private DataElementConcept myDEC;
	private ValueDomain myValDom;
	private RefDocList myRDL;
	
	private String myPrefQues;
	private String myBridgClass;
	private String myBridgAttr;
	private String myBridgMap;
	
	
	public int getId() {
		return id;
	}

	@XmlAttribute(name="num")
	public void setId(int idm) {
		this.id = idm;
	}


	public String getPublic_ID() {
		return Public_ID;
	}
	
	@XmlElement(name="PUBLICID")
	public void setPublic_ID(String public_ID) {
		Public_ID = public_ID;
	}
	public String getLong_Name() {
		return Long_Name;
	}
	
	@XmlElement(name = "LONGNAME")
	public void setLong_Name(String long_Name) {
		Long_Name = long_Name;
	}
	
	/**
	 * @return the pref_Def
	 */
	public String getPref_Def() {
		return Pref_Def;
	}
	/**
	 * @param pref_Def the pref_Def to set
	 */
	@XmlElement(name="PREFERREDDEFINITION")
	public void setPref_Def(String pref_Def) {
		Pref_Def = pref_Def;
	}
	/**
	 * @return the context_Name
	 */
	public String getContext_Name() {
		return Context_Name;
	}
	/**
	 * @param context_Name the context_Name to set
	 */
	@XmlElement(name="CONTEXTNAME")
	public void setContext_Name(String context_Name) {
		Context_Name = context_Name;
	}
	

	public RefDocList getMyRDL() {
		return myRDL;
	}

	@XmlElement(name="REFERENCEDOCUMENTSLIST")
	public void setMyRDL(RefDocList myRDL) {
		this.myRDL = myRDL;
	}

	public DataElementConcept getMyDEC() {
		return myDEC;
	}

	@XmlElement(name="DATAELEMENTCONCEPT")
	public void setMyDEC(DataElementConcept my_DEC) {
		this.myDEC = my_DEC;
	}

	public AlternateNames getMyANL() {
		return myANL;
	}

	@XmlElement(name="ALTERNATENAMELIST")
	public void setMyANL(AlternateNames myANL) {
		this.myANL = myANL;
	}

	public ValueDomain getMyValDom() {
		return myValDom;
	}

	@XmlElement(name="VALUEDOMAIN")
	public void setMyValDom(ValueDomain myValDom) {
		this.myValDom = myValDom;
	}

	/**
	 * @return the myPrefQues
	 */
	public String getMyPrefQues() {
		return myPrefQues;
	}

	/**
	 * @param myPrefQues the myPrefQues to set
	 */
	public void setMyPrefQues(String myPrefQues) {
		this.myPrefQues = myPrefQues;
	}

	/**
	 * @return the myBridgClass
	 */
	public String getMyBridgClass() {
		return myBridgClass;
	}

	/**
	 * @param myBridgClass the myBridgClass to set
	 */
	public void setMyBridgClass(String myBridgClass) {
		this.myBridgClass = myBridgClass;
	}

	/**
	 * @return the myBridgAttr
	 */
	public String getMyBridgAttr() {
		return myBridgAttr;
	}

	/**
	 * @param myBridgAttr the myBridgAttr to set
	 */
	public void setMyBridgAttr(String myBridgAttr) {
		this.myBridgAttr = myBridgAttr;
	}

	/**
	 * @return the myBridgMap
	 */
	public String getMyBridgMap() {
		return myBridgMap;
	}

	/**
	 * @param myBridgMap the myBridgMap to set
	 */
	public void setMyBridgMap(String myBridgMap) {
		this.myBridgMap = myBridgMap;
	}
	
	
	

}
