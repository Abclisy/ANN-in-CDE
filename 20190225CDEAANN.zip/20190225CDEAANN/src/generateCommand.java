import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class generateCommand {

	public static void main(String[] args) throws IOException {
	      

	       //double k=Math.random();
	       
		/*
	       for(int i=1;i<=100;i++) {
		       //System.out.println(Math.sqrt(0.01)*randomno.nextGaussian()+0);

		       Random randomno = new Random();
		       System.out.println(Math.sqrt(0.01)*randomno.nextGaussian()+0);
	    	   
	       }
	       */
		// TODO Auto-generated method stub
		 //FileOutputStream f = new FileOutputStream("command.txt");
		 //System.setOut(new PrintStream(f));
	       
		 generateCommand();
	}

	public static void generateCommand() {

		List<String> train_element_in_cls=new ArrayList<String>();//1
		List<String> target_v2Only=new ArrayList<String>();//2, first try version 1
		List<String> topN=new ArrayList<String>();//3
		List<String> errorV1=new ArrayList<String>();//4
		List<String> threshold=new ArrayList<String>();//5
		List<String> iterationTimes=new ArrayList<String>();//6
		List<String> learningRate=new ArrayList<String>();//7
		List<String> trainClsSequence=new ArrayList<String>();//8
		List<String> trVe31or91=new ArrayList<String>();//8
		
		//1
		for(int i=4;i<=10;i++) {
			train_element_in_cls.add(Integer.toString(i));
		}
		//2
			//when errorV1.add("true");
			target_v2Only.add("0");
			
			//when errorV1.add("false");
			/**/
			//target_v2Only.add("1");
			//target_v2Only.add("0.9");
			//target_v2Only.add("0.8");
			//target_v2Only.add("0.7");
			//target_v2Only.add("0.6");
						
		//3
			topN.add("10");
		//4
		errorV1.add("true");
		//errorV1.add("false");
		//5
		//for(int i=7;i<=10;i++) {
		//	threshold.add(Float.toString((float) (i*0.1)));
		//}
		for(int i=6;i<=10;i++) {
			threshold.add(Float.toString((float) (i*0.1)));
		}
		//6
		iterationTimes.add("50");
		//iterationTimes.add("100");
		//7
		learningRate.add("0.05");
		//8
		//trainClsSequence.add("1");
		trainClsSequence.add("2");
		//9
		trVe31or91.add("31");
		trVe31or91.add("91");
		
		System.out.println("rem 1. train_element_in_cls="+train_element_in_cls);
		System.out.println("rem 2. target_v2Only="+target_v2Only);
		System.out.println("rem 3. topN="+topN);
		System.out.println("rem 4. errorV1="+errorV1);
		System.out.println("rem 5. threshold="+threshold);
		System.out.println("rem 6. iterationTimes="+iterationTimes);
		System.out.println("rem 7. learningRate="+learningRate);
		System.out.println("rem 8. trainClsSequence="+trainClsSequence);
		System.out.println("rem 9. trVe31or91="+trVe31or91);

        List<String> iterator1 = train_element_in_cls ;  
        List<String> iterator2 = target_v2Only ;  
        List<String> iterator3 = topN ;  
        List<String> iterator4 = errorV1 ;  
        List<String> iterator5 = threshold ;  
        List<String> iterator6 = iterationTimes ;  
        List<String> iterator7 = learningRate ;  
        List<String> iterator8 = trainClsSequence ;
        List<String> iterator9 = trVe31or91 ;
        
        
        for(int i1=0;i1<iterator1.size();i1++) {
            for(int i2=0;i2<iterator2.size();i2++) {
                for(int i3=0;i3<iterator3.size();i3++) {
                    for(int i4=0;i4<iterator4.size();i4++) {
                        for(int i5=0;i5<iterator5.size();i5++) {
                            for(int i6=0;i6<iterator6.size();i6++) {
                                for(int i7=0;i7<iterator7.size();i7++) {
                                    for(int i8=0;i8<iterator8.size();i8++) {
                                        for(int i9=0;i9<iterator9.size();i9++) {
                                        
                                        if(iterator9.get(i9)=="91"){
                                        	if(Integer.parseInt(iterator1.get(i1))<10) {
                                        		System.out.print("rem ");
                                        	}
                                        }
                                    	System.out.print("java -jar --add-modules java.xml.bind CDEANN_Train-and-Verification.jar "); 
                                        System.out.print(iterator1.get(i1));  
                                        generateSpace();  
                                        System.out.print(iterator2.get(i2)); 
                                        generateSpace();  
                                        System.out.print(iterator3.get(i3));  
                                        generateSpace();  
                                        System.out.print(iterator4.get(i4)); 
                                        generateSpace();  
                                        System.out.print(iterator5.get(i5)); 
                                        generateSpace();
                                        System.out.print(iterator6.get(i6)); 
                                        generateSpace();
                                        System.out.print(iterator7.get(i7)); 
                                        generateSpace();  
                                        System.out.print(iterator8.get(i8));  
                                        generateSpace();  
                                        System.out.print(iterator9.get(i9));  
                                        System.out.println("");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
	}
	
	public static void generateSpace() {
        System.out.print(" ");  
	}
}
