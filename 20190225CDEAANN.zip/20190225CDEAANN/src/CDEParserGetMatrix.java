
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;




public class CDEParserGetMatrix {
	public static int cdeNo=0;
	static int getMatrixAmt=CDEParserGetMatrixAmt.getMatrixAmt();
	//9 is to add HCT_BRIDG and HCT_BRIDG_5
	static String CDEMatrix[][]=new String[8][getMatrixAmt+1];
	static String CDESimMatrix[][]=new String[getMatrixAmt+1][getMatrixAmt+1];
	static List<String> XMLFiles= new ArrayList<String>();
	private static List<CDE> myCDES= new ArrayList<CDE>();
	public static List<String> UBClass=new ArrayList<String>();
	
	public static Map<String, List<CDE>> bridgList=new HashMap<String, List<CDE>>();

	public static void main(String[] args) throws FileNotFoundException {
		FileOutputStream f = new FileOutputStream("logcde.txt");
		System.setOut(new PrintStream(f)); 
		//System.out.println(CDEParserGetMatrixAmt.getMatrixAmt());
		/*
		FileOutputStream f = new FileOutputStream("logcde.txt");
		System.setOut(new PrintStream(f)); 
		
	    System.out.println("Started");
	    //CDEParser CDEAANN;
	    outputCurrentTime("1. Start parsing xml files --- ");
	    getXmlFiles();
	    if(XMLFiles.isEmpty())
	    {
	    	System.err.println("No XML Files located" );
	    }
	    for(String s: XMLFiles)
	    {
	    	System.out.println("the xml files are: "+ s);
	    	String file_Name= new String(s);
	    	outputCurrentTime("Now parsing file:: "+file_Name);
	    	generateXML(file_Name);
	    }
	    
	    BridgList();
	    
	    for(String s1:bridgList.keySet())
	    {
	    	System.out.println("BRIDG_Class::"+s1+"-->COUNT::"+bridgList.get(s1).size());
	    }
	    
	    System.out.println("TOTAL BRIDGS--->"+bridgList.size());
	    
	    int count=0;
	    
	    for(String s:bridgList.keySet())
	    {
	    	if(bridgList.get(s).size()>=10)
	    	{
	    		count++;
	    	}
	    }
	    System.out.println("BRIDGS with only 1 result===>"+count);

	    
	    //li sCDESimMatrix get Similarity
	    double s1,s2,s3,s4,s5,s6;
	    double d1,d2,d3,d4,d5,d6;
	    double l1,l2,l3,l4,l5,l6;
	    
	    //��һ�е�i��Ԫ�غ͵�һ�е�j��Ԫ��
	    
	    for(int i = 1; i <= 1232; i = i+1) {
	    	for(int j = 1; j <= 1232; j = j+1) {
	    		
			    d1=StringEditDistance.getDistance(CDEMatrix[1][i],CDEMatrix[1][j]);
			    d2=StringEditDistance.getDistance(CDEMatrix[2][i],CDEMatrix[2][j]);
			    d3=StringEditDistance.getDistance(CDEMatrix[3][i],CDEMatrix[3][j]);
			    d4=StringEditDistance.getDistance(CDEMatrix[4][i],CDEMatrix[4][j]);
			    d5=StringEditDistance.getDistance(CDEMatrix[5][i],CDEMatrix[5][j]);
			    d6=StringEditDistance.getDistance(CDEMatrix[6][i],CDEMatrix[6][j]);
			    //l1=CDEMatrix[6][i]��CDEMatrix[6][j])�����ַ����ĳ���
			    l1=(CDEMatrix[1][i].length()>CDEMatrix[1][j].length())?CDEMatrix[1][i].length():CDEMatrix[1][j].length();
			    l2=(CDEMatrix[2][i].length()>CDEMatrix[2][j].length())?CDEMatrix[2][i].length():CDEMatrix[2][j].length();
			    l3=(CDEMatrix[3][i].length()>CDEMatrix[3][j].length())?CDEMatrix[3][i].length():CDEMatrix[3][j].length();
			    l4=(CDEMatrix[4][i].length()>CDEMatrix[4][j].length())?CDEMatrix[4][i].length():CDEMatrix[4][j].length();
			    l5=(CDEMatrix[5][i].length()>CDEMatrix[5][j].length())?CDEMatrix[5][i].length():CDEMatrix[5][j].length();
			    l6=(CDEMatrix[6][i].length()>CDEMatrix[6][j].length())?CDEMatrix[6][i].length():CDEMatrix[6][j].length();

			    s1=CDEMatrix[1][i].equals(CDEMatrix[1][j])?1:(1-d1/l1);
			    s2=CDEMatrix[2][i].equals(CDEMatrix[2][j])?1:(1-d2/l2);
			    s3=CDEMatrix[3][i].equals(CDEMatrix[3][j])?1:(1-d3/l3);
			    s4=CDEMatrix[4][i].equals(CDEMatrix[4][j])?1:(1-d4/l4);
			    s5=CDEMatrix[5][i].equals(CDEMatrix[5][j])?1:(1-d5/l5);
			    s6=CDEMatrix[6][i].equals(CDEMatrix[6][j])?1:(1-d6/l6);
			    
			    DecimalFormat df = new DecimalFormat("0.00");
			    s1=Double.parseDouble(df.format(s1));
			    s2=Double.parseDouble(df.format(s2));
			    s3=Double.parseDouble(df.format(s3));
			    s4=Double.parseDouble(df.format(s4));
			    s5=Double.parseDouble(df.format(s5));
			    s6=Double.parseDouble(df.format(s6));
			    
			    CDESimMatrix[i][j]=("simVecMatrix"+"["+i+"]"+"["+j+"]="+s1+"#"+s2+"#"+s3+"#"+s4+"#"+s5+"#"+s6+";");
			    System.out.println(CDESimMatrix[i][j]);
	    	}
	    }
	    */
	    
	    //get training example
	    /*
	    for(int i = 1; i <= 1232; i = i+1) {
	    	for(int j = 1; j <= 1232; j = j+1) {
			    if(CDEMatrix[7][i].equals(CDEMatrix[7][j])) {
	    		System.out.println("trainingExamples"+"."+"add("+"\""+i+"@"+j+"\");");
			    }
	    	}
	    }
	    */
	    
	    //get training example no replicated
	    /*
	    for(int i = 1; i <= 1232; i = i+1) {
	    	for(int j = 1; j <= 1232; j = j+1) {
		    	if(i>j) {j=i;}
				    if(CDEMatrix[7][i].equals(CDEMatrix[7][j])) {
		    		System.out.println("trainingExamples"+"."+"add("+"\""+i+"@"+j+"\");");
				    }
		    	
	    	}
	    }
	    */
		
		//generateXML("CDEBrowser_SearchResults");
		generateXML("CDEBrowser_SearchResults");
	}
	
	
	static void generateXML(String file_Name)  {
		try
		{
		File fXmlFile = new File(file_Name.trim()+".xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(CDElist.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		CDElist cdelist = (CDElist) jaxbUnmarshaller.unmarshal(fXmlFile);
		List<CDE> n=cdelist.getPhoneNumber();
		 Iterator<CDE> itr=n.iterator();
		 int nulcount=0;
		 
		 //int cou=0;
		 //cou=cou+1;
		 
		 while (itr.hasNext()) {
			    //li
			    cdeNo++;
			    ////System.out.println("cdeNo:"+cdeNo);
			 
		 CDE cde=itr.next();
		 //System.out.println("CDE_NUMBER: "+cde.getId());
		 System.out.print("CDE_NAME: "+cde.getLong_Name());
		 System.out.print("	");
		 //System.out.println("CDE_ID: "+cde.getPublic_ID());
		 //System.out.println("CDE_CONCEPT_NAME: "+cde.getMyDEC().getLong_Name());
		 //System.out.println("CDE_CONCEPT_ID: "+cde.getMyDEC().getConcept_ID());
		 System.out.print("CDE_OBJCLS: "+cde.getMyDEC().getMy_objclass().getLong_Name());
		 System.out.print("	");
		 System.out.print("CDE_PROP: "+cde.getMyDEC().getMy_prop().getLong_Name());
		 System.out.print("	");
		 System.out.print("CDE_VALDOM: "+cde.getMyValDom().getLong_Name());
		 System.out.print("	");
		 System.out.print("CDE_REPSNTN: "+cde.getMyValDom().getRepresentation_Term().getLong_Name());/*//li*/
		 System.out.print("	");
		 //lisy Store CDE into Matrix
		 //String CDEMatrix[][]=new String[6][1233];
		 CDEMatrix[1][cdeNo]=cde.getLong_Name();
		 CDEMatrix[2][cdeNo]=cde.getMyDEC().getMy_objclass().getLong_Name();
		 CDEMatrix[3][cdeNo]=cde.getMyDEC().getMy_prop().getLong_Name();
		 CDEMatrix[4][cdeNo]=cde.getMyValDom().getLong_Name();
		 CDEMatrix[5][cdeNo]=cde.getMyValDom().getRepresentation_Term().getLong_Name();
		 
		 List<AlterListItem> mynames=cde.getMyANL().getANL();
		 Iterator<AlterListItem> ALI=mynames.iterator();
		while(ALI.hasNext())
		{
			AlterListItem li=ALI.next();
			//20181231 - added "HCT_BRIDG_5"
			
			if(li.getAlt_type().equalsIgnoreCase("HCT_BRIDG_5")|li.getAlt_type().equalsIgnoreCase("HCT_BRIDG"))
			{
				//System.out.println();
				
				System.out.print("Alt_type: "+li.getAlt_type());
				System.out.print("	");
				
				cde.getMyANL().getANL().get(cde.getMyANL().getANL().indexOf(li)).setBRIDG_class(li.getAlt_name().split(":")[0]);
				
				//cde.getMyANL().getANL().get(cde.getMyANL().getANL().indexOf(li)).setBRIDG_Attr(li.getAlt_name().split(":")[1]);mohan
				cde.getMyANL().getANL().get(cde.getMyANL().getANL().indexOf(li)).setBRIDG_Attr(li.getAlt_name().split(":")[0]);
				
				cde.getMyANL().getANL().get(cde.getMyANL().getANL().indexOf(li)).setHCT_Type(true);
				cde.setMyBridgClass(li.getAlt_name().split(":")[0]);
				
				//cde.setMyBridgAttr(li.getAlt_name().split(":")[1]);mohan
				cde.setMyBridgAttr(li.getAlt_name().split(":")[0]);
				break;
				
				
			}else {
				
				
			}
		}
		
		/*for(int i=0; i< cde.getMyANL().getANL().size();i++)
		{
			if(cde.getMyANL().getANL().get(i).isHCT_Type())
			{
				System.out.println(cde.getMyANL().getANL().get(i).getBRIDG_class()+"::BRIDG_CLASS");
				System.out.println(cde.getMyANL().getANL().get(i).getBRIDG_Attr()+"::BRIDG_Attr");
				break;
			}
		}*/
		
		List<RefDocListItem> myrefItem=cde.getMyRDL().getANL();
		Iterator<RefDocListItem> RDLI=myrefItem.iterator();
		while(RDLI.hasNext())
		{
			RefDocListItem rdli=RDLI.next();
			if(rdli.getDoc_type().equalsIgnoreCase("Preferred Question Text"))
			{
				cde.getMyRDL().getANL().get(cde.getMyRDL().getANL().indexOf(rdli)).setIs_pref(true);
				cde.setMyPrefQues(rdli.getDoc_Text());
			}
			if(rdli.getDoc_type().equalsIgnoreCase("BRIDG Mapping Path"))
			{
				cde.getMyRDL().getANL().get(cde.getMyRDL().getANL().indexOf(rdli)).setBRIDG_Path(rdli.getDoc_Text());
				cde.setMyBridgMap(rdli.getDoc_Text());
			}
		}
		
		
			myCDES.add(cde);
			

			
		
		//li
		System.out.print("PREF_QUES:"+cde.getMyPrefQues());
		System.out.print("	");
		System.out.print("BRIDG_CLASS:"+cde.getMyBridgClass());
		System.out.println("	");
		CDEMatrix[6][cdeNo]=cde.getMyPrefQues();
		//li
		CDEMatrix[7][cdeNo]=cde.getMyBridgClass().trim().toLowerCase();
		//System.out.println("BRIDG_ATTR:"+cde.getMyBridgAttr());
		//System.out.println("BRIDG_MAP:"+cde.getMyBridgMap());
		
		

		 //System.out.println("---------------------");
		////System.out.println("**************");
		/**/

		 }
		
		//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	public static void BridgList()
	{
		
		
		for(CDE cde:myCDES)
		{
			if(bridgList.containsKey(cde.getMyBridgClass().trim()))
			{
				if(!(bridgList.get(cde.getMyBridgClass().trim())).contains(cde))
				{
					for(String s:bridgList.keySet())
					{
						if(s.equalsIgnoreCase(cde.getMyBridgClass().trim()))
						{
							bridgList.get(s).add(cde);
						}
					}
				}
				
			}
		else
		{
			bridgList.put(cde.getMyBridgClass().trim(), new ArrayList<CDE>());
			bridgList.get(cde.getMyBridgClass().trim()).add(cde);
			
		}
		
			
		}
		
	
	}
	public void fillUBridgs(CDE cde)
	{
		cde.getMyBridgClass();
	}

	//======================================================================
    // a method to get the list of XML files from the file "XMLFiles.txt"
    //======================================================================
	static void getXmlFiles() {
		//System.out.println("Working Directory = " +System.getProperty("user.dir"));
		try {
            BufferedReader infile = new BufferedReader(new FileReader("XMLFiles.txt"));
            while(infile.ready())
            {
            	XMLFiles.add(new String(infile.readLine().trim()));
            }
            infile.close();
		}
		catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
            System.out.println("File: XMLFiles.txt does not exist!");
          }
          catch (IOException ioe) {
            ioe.printStackTrace();
          }
		
		
	}
	public static void outputCurrentTime(String scenario) {
        Calendar cal = new GregorianCalendar();
        int hour24, min, sec;
        //int hour12;
        //hour12 = cal.get(Calendar.HOUR);
        hour24 = cal.get(Calendar.HOUR_OF_DAY);
        min = cal.get(Calendar.MINUTE);
        sec = cal.get(Calendar.SECOND);
        System.out.println(scenario + hour24 + ":" + min + ":" + sec);
      }
	static class StringEditDistance{
	    /*���������ַ����������������ַ����ı༭����*/
	    public static int getDistance(String strA, String strB){
	        int distance=-1;
	        /*��������Ϸ��Լ��*/
	        if(null==strA||null==strB||strA.isEmpty()||strB.isEmpty()){
	            return distance;
	        }
	        /*�����ַ�����ȣ��༭����Ϊ0*/
	        if (strA.equals(strB)) {
	            return 0;
	        }
	        //System.out.println("First String:"+strA);
	        //System.out.println("Second String:"+strB);
	        int lengthA=strA.length();
	        int lengthB=strB.length();
	        int length=Math.max(lengthA,lengthB);
	        /*����һ����ά���飬�洢ת�ƾ���*/
	        int array[][]=new int[length+1][length+1];
	        /*�߽�������ʼ��*/
	        for(int i=0;i<=length;i++){
	            array[i][0]=i;

	        }
	        /*�߽�������ʼ��*/
	        for(int j=0;j<=length;j++){
	            array[0][j]=j;
	        }
	        /*״̬ת�Ʒ���*/
	        for(int i=1;i<=lengthA;i++){
	            for(int j=1;j<=lengthB;j++){
	                array[i][j]=min(array[i-1][j]+1,
	                                array[i][j-1]+1,
	                                array[i-1][j-1]+(strA.charAt(i-1)==strB.charAt(j-1)?0:1));
	            }
	        }
	        /*��ӡת�Ʊ���
	        System.out.println("״̬ת�Ʊ���");
	        for(int i=0;i<=lengthA;i++){
	            for(int j=0;j<=lengthB;j++){
	               System.out.print( array[i][j]+"    ");
	            }
	            System.out.println();
	        }
	        */
	        return array[lengthA][lengthB];

	    }
	    /*ȡ�������е���Сֵ*/
	    public static int  min(int a,int b, int c){
	        return Math.min(Math.min(a,b),c);
	    }
	}
}
