
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="REFERENCEDOCUMENTSLIST")
public class RefDocList {
	
	@XmlElement(name="REFERENCEDOCUMENTSLIST_ITEM")
	private List<RefDocListItem> my_Items=new ArrayList<RefDocListItem>();
	
	/**
	 * @return the items
	 */
	public List<RefDocListItem> getANL() {
        if (my_Items==null) {
        	System.out.println("new Ref doc Item created");
        	my_Items=new ArrayList<RefDocListItem>();
        }
        return this.my_Items;
    }

	
	
	
	
	

}
