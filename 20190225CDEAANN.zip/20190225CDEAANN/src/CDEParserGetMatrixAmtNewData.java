
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;




public class CDEParserGetMatrixAmtNewData {
	private static final String CDEBrowser_SearchResults2 = null;
	public static int cdeNo=0;
	static List<String> XMLFiles= new ArrayList<String>();
	private static List<CDE> myCDES= new ArrayList<CDE>();
	public static List<String> UBClass=new ArrayList<String>();
	
	public static Map<String, List<CDE>> bridgList=new HashMap<String, List<CDE>>();

	public static void main(String[] args) throws FileNotFoundException {
		//System.out.println(getMatrixAmt(CDEBrowser_SearchResults2));
	}
	
	static int getMatrixAmt()  {
		
		System.out.println("Started");
		// CDEParser CDEAANN;
		CDEParserGetMatrixAmtNewData.getXmlFiles();
		if (CDEParserGetMatrixAmtNewData.XMLFiles.isEmpty()) {
			System.err.println("No XML Files located");
		}
		//for (String s : CDEParserGetMatrixAmtNewData.XMLFiles) {
			//System.out.println("the xml files are: " + s);
			//String file_Name = new String(s);
			//CDEParserGetMatrix.generateXML(file_Name0);
			String file_Name="CDEBrowser_SearchResults2";
			try
			{
			File fXmlFile = new File(file_Name.trim()+".xml");
			JAXBContext jaxbContext = JAXBContext.newInstance(CDElist.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			CDElist cdelist = (CDElist) jaxbUnmarshaller.unmarshal(fXmlFile);
			List<CDE> n=cdelist.getPhoneNumber();
			 Iterator<CDE> itr=n.iterator();
			 int nulcount=0;

			 cdeNo=0;
			 while (itr.hasNext()) {
				    cdeNo++;
				 
			 CDE cde=itr.next();
			 }
			
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		//}
		

		return cdeNo;
		
		
	}


	//======================================================================
    // a method to get the list of XML files from the file "XMLFiles.txt"
    //======================================================================
	static void getXmlFiles() {
		//System.out.println("Working Directory = " +System.getProperty("user.dir"));
		try {
            BufferedReader infile = new BufferedReader(new FileReader("XMLFiles.txt"));
            while(infile.ready())
            {
            	XMLFiles.add(new String(infile.readLine().trim()));
            }
            infile.close();
		}
		catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
            System.out.println("File: XMLFiles.txt does not exist!");
          }
          catch (IOException ioe) {
            ioe.printStackTrace();
          }
		
		
	}

}
