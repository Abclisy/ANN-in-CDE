
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Property")
public class property {
	
private String Long_Name;
private String P_ID;


/**
 * @return the p_ID
 */
public String getP_ID() {
	return P_ID;
}

/**
 * @param p_ID the p_ID to set
 */
@XmlElement(name="PublicId")
public void setP_ID(String p_ID) {
	P_ID = p_ID;
}

/**
 * @return the long_Name
 */
public String getLong_Name() {
	return Long_Name;
}

/**
 * @param long_Name the long_Name to set
 */
@XmlElement(name="LongName")
public void setLong_Name(String long_Name) {
	Long_Name = long_Name;
}
}
