import java.awt.Desktop;
import java.io.*;
import java.net.URI;
import java.text.DecimalFormat;
import java.util.*;

//modified by lisy - into max & min example
/**
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 * <p>
 * Company: USC
 * </p>
 * 
 * @author Jingshan Huang
 * @version 1.0
 */

public class DeltaRuleAlgAverage_NotSplitTrainAndVerification_noEntrance {
	static double target_v2Only=0.5;
	static int topN=10;
	static int if1notbad=0;
	static boolean max_sAvg_LargerThan_sOtherAvg;
	static double errorking;
	static boolean errorV1 = true;//---true, false 
	static double threshold = 1.0;//---------------0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9
	static String simVecMatrix[][] = new String[1233][2]; // each cell is a string (e.g. "0.85#0.27#0.56"), recording
	static String simMatrixComp[][]; // the similarity values for 2 concepts in 3 dimensions
	double justnow = 0; // (name, property, and ancestor)
	public double[][] simMatrix; // similarity matrix recalculated using the learned weights
	public static int iterationTimes = 50; //---50,100      // how many iterations in running Delta Rule algorithm, will try 10, 15, 20,
											// 30,
	// 50, 80, 100, 200, 500, 1000, 1500, 2500, and 5000.
	public double learningRate = 0.05; // will try 0.05, 0.1, and 0.2
	public static double w1 = 1.0 / 6, w2 = 1.0 / 6, w3 = 1.0 / 6, w4 = 1.0 / 6, w5 = 1.0 / 6, w6 = 1.0 / 6; // initialize

	// public DeltaRule(String[][] matrix) {
	public DeltaRuleAlgAverage_NotSplitTrainAndVerification_noEntrance() {
		gradientDescent();
		verification(w1, w2, w3, w4, w5, w6);
	}

	public static void main(String[] args) throws FileNotFoundException {
		String version=(errorV1)?"EV2":"EV1";
		// FileOutputStream f = new
		// FileOutputStream("logErrLisyThreshold0d6iterationTime1000learningrate0d05.txt");
		 FileOutputStream f = new FileOutputStream("log_notHalf_top"+topN+"_"+version  +"_threshold"+threshold+ "_iterationT"+iterationTimes+"_target_v2Only"+target_v2Only+"_noEntry"+".txt");
		 System.setOut(new PrintStream(f));

		System.out.println("getSimMatrix()...");
		simMatrixComp = getSimMatrix();

		System.out.println("finish getSimMatrix()");

		DeltaRuleAlgAverage_NotSplitTrainAndVerification_noEntrance deltarule = new DeltaRuleAlgAverage_NotSplitTrainAndVerification_noEntrance();
		// System.out.println("Begin error V2(Dr. Huang)");
		// verification(w1,w2,w3,w4,w5,w6);
		// DeltaRuleAlgAverage deltaruleV2 = new DeltaRuleAlgAverage();
		
		//��ɺ����ʾ
		try {
			  Desktop desktop = java.awt.Desktop.getDesktop();
			  URI oURL = new URI("http://www.google.com");
			  desktop.browse(oURL);
			} catch (Exception e) {
			  e.printStackTrace();
			}

	}

	private static String[][] getSimMatrix() {
		System.out.println("Started");
		// CDEParser CDEAANN;
		CDEParserGetMatrix.outputCurrentTime("1. Start parsing xml files --- ");
		CDEParserGetMatrix.getXmlFiles();
		if (CDEParserGetMatrix.XMLFiles.isEmpty()) {
			System.err.println("No XML Files located");
		}
		for (String s : CDEParserGetMatrix.XMLFiles) {
			System.out.println("the xml files are: " + s);
			String file_Name = new String(s);
			CDEParserGetMatrix.outputCurrentTime("Now parsing file:: " + file_Name);
			CDEParserGetMatrix.generateXML(file_Name);
		}
		// String matrix[][]=new String[1233][2];
		// get similarity matrix with 6 aspects of similarity
		// li sCDESimMatrix get Similarity
		double s1, s2, s3, s4, s5, s6;

		for (int i = 1; i <= 1232; i = i + 1) {
			System.out.println("i=" + i);
			for (int j = 1; j <= 1232; j = j + 1) {
				// String SameCls="0";
				// System.out.println("Comparing: " + CDEParserGetMatrix.CDEMatrix[1][i]+" and "
				// +CDEParserGetMatrix.CDEMatrix[1][j]);

				// they all belongs to organize class
				/*
				 * if(CDEParserGetMatrix.CDEMatrix[7][i].equals(CDEParserGetMatrix.CDEMatrix[7][
				 * j])&&CDEParserGetMatrix.CDEMatrix[7][j].equals("Organization")) {
				 * SameCls="1"; }
				 */
				// s calculation: letter by letter
				// System.out.println("cde1="+CDEParserGetMatrix.CDEMatrix[1][i] + " " +
				// "cde2="+CDEParserGetMatrix.CDEMatrix[1][j]);
				s1 = getStringSim(CDEParserGetMatrix.CDEMatrix[1][i], CDEParserGetMatrix.CDEMatrix[1][j]);
				// System.out.println("cde1="+CDEParserGetMatrix.CDEMatrix[2][i] + " " +
				// "cde2="+CDEParserGetMatrix.CDEMatrix[2][j]);
				s2 = getStringSim(CDEParserGetMatrix.CDEMatrix[2][i], CDEParserGetMatrix.CDEMatrix[2][j]);
				// System.out.println("cde1="+CDEParserGetMatrix.CDEMatrix[3][i] + " " +
				// "cde2="+CDEParserGetMatrix.CDEMatrix[3][j]);
				s3 = getStringSim(CDEParserGetMatrix.CDEMatrix[3][i], CDEParserGetMatrix.CDEMatrix[3][j]);
				// System.out.println("cde1="+CDEParserGetMatrix.CDEMatrix[4][i] + " " +
				// "cde2="+CDEParserGetMatrix.CDEMatrix[4][j]);
				s4 = getStringSim(CDEParserGetMatrix.CDEMatrix[4][i], CDEParserGetMatrix.CDEMatrix[4][j]);
				// System.out.println("cde1="+CDEParserGetMatrix.CDEMatrix[5][i] + " " +
				// "cde2="+CDEParserGetMatrix.CDEMatrix[5][j]);
				s5 = getStringSim(CDEParserGetMatrix.CDEMatrix[5][i], CDEParserGetMatrix.CDEMatrix[5][j]);
				// System.out.println("cde1="+CDEParserGetMatrix.CDEMatrix[6][i] + " " +"cde2="+
				// CDEParserGetMatrix.CDEMatrix[6][j]);
				s6 = getStringSim(CDEParserGetMatrix.CDEMatrix[6][i], CDEParserGetMatrix.CDEMatrix[6][j]);

				/*
				 * if(SameCls.equals("1")) {
				 * System.out.println("making the s1#s2#s3#s4#s5#s6 matrix");
				 * System.out.println("s1#s2#s3#s4#s5#s6= "+s1 + "#" + s2 + "#" + s3 + "#" + s4
				 * + "#" + s5 + "#" + s6); System.out.println("i="+i+"; j="+j);
				 * 
				 * }
				 */
				// System.out.println("i="+i);
				/*
				 * DecimalFormat df = new DecimalFormat("0.00"); s1 =
				 * Double.parseDouble(df.format(s1)); s2 = Double.parseDouble(df.format(s2)); s3
				 * = Double.parseDouble(df.format(s3)); s4 = Double.parseDouble(df.format(s4));
				 * s5 = Double.parseDouble(df.format(s5)); s6 =
				 * Double.parseDouble(df.format(s6));
				 */

				CDEParserGetMatrix.CDESimMatrix[i][j] = (s1 + "#" + s2 + "#" + s3 + "#" + s4 + "#" + s5 + "#" + s6);
				// System.out.println(CDEParserGetMatrix.CDESimMatrix[i][j]);
			}
		}
		return CDEParserGetMatrix.CDESimMatrix;
	}

	private static double getStringSim(String cde1, String cde2) {
		// System.out.println("Begin processing two cde property-----------");
		cde1 = cde1.toLowerCase();
		cde2 = cde2.toLowerCase();
		double s;

		// System.out.println("cde1=" + cde1);
		// System.out.println("cde2=" + cde2);

		// same cde
		if (cde1.equals(cde2)) {
			s = 1;
			// System.out.println("----Same cde--s--1");

			// not same cde
		} else {
			// System.out.println("----Not Same cde");
			double max = 0;
			List<Integer> delListi = new ArrayList<Integer>();
			List<Integer> delListj = new ArrayList<Integer>();
			// initialize i
			int tempDeli = 0, tempDelj = 0;
			double match = 0;

			// String[] arr1 = cde1.split("[^a-zA-Z0-9]+");
			// String[] arr2 = cde2.split("[^a-zA-Z0-9]+");
			String[] arr1 = cde1.split(" ");
			String[] arr2 = cde2.split(" ");

			List<String> cde1L = Arrays.asList(arr1);
			List<String> cde2L = Arrays.asList(arr2);
			// System.out.println("cde1L=" + cde1L);
			// System.out.println("cde2L=" + cde2L);
			double smallerSize = cde1L.size() < cde2L.size() ? cde1L.size() : cde2L.size();

			Double[][] wordSimMatrix = new Double[cde1L.size() + 1][cde2L.size() + 1];

			// Word Matrix generate
			for (int i = 0; i <= cde1L.size() - 1; i++) {
				for (int j = 0; j <= cde2L.size() - 1; j++) {
					double d;
					double l;
					// System.out.println("Comparing word [" + cde1L.get(i) + "] and word [" +
					// cde2L.get(j) + "]");

					// same word
					if (cde1L.get(i).equals(cde2L.get(j))) {
						// System.out.println("-Same word");
						wordSimMatrix[i + 1][j + 1] = 1.0;

						// System.out.println("i+1=" + (i + 1));
						// System.out.println("j+1=" + (j + 1));
						// not same word
					} else {
						// System.out.println("-Not same word");
						d = editDistDP(cde1L.get(i), cde2L.get(j), cde1L.get(i).length(), cde2L.get(j).length());
						l = (cde1L.get(i).length() > cde2L.get(j).length()) ? cde1L.get(i).length()
								: cde2L.get(j).length();

						// System.out.println("i+1=" + (i + 1));
						// System.out.println("j+1=" + (j + 1));
						wordSimMatrix[i + 1][j + 1] = 1 - d / l;
					}
				}
			}

			// Show generated Matrix
			// System.out.println((wordSimMatrix[1][1])+"
			// "+(wordSimMatrix[1][2])+(wordSimMatrix[1][3])+" "+(wordSimMatrix[1][4]));
			// System.out.println((wordSimMatrix[2][1])+"
			// "+(wordSimMatrix[2][2])+(wordSimMatrix[2][3])+" "+(wordSimMatrix[2][4]));
			// System.out.println((wordSimMatrix[5][1])+" "+(wordSimMatrix[5][2]));
			// have the iteration times with the smaller s
			for (int n = 1; n <= smallerSize; n++) {
				// begin the search in wordSmMatrix[][]

				for (int i = 1; i <= cde1L.size(); i++) {
					for (int j = 1; j <= cde2L.size(); j++) {

						// System.out.println("i=" + i);
						// System.out.println("j=" + j);
						// will not take the rol and col which have been picked up into account
						if (delListi.size() == 0 || delListj.size() == 0) {
							// System.out.println("Have no delListi and delListj");
							// find the max num
							if (wordSimMatrix[i][j] > max) {
								max = wordSimMatrix[i][j];
								// System.out.println("max=" + max);
								tempDeli = i;
								tempDelj = j;
							}

						} else {
							// System.out.println("Have delListi and delListj");
							// if this col and col have been picked up before
							if (delListi.contains(i) || delListj.contains(j)) {

								// System.out.println("skip this col(" + i + ")" + " or row(" + j + ")");

								// if this col and col havn't been picked up before
							} else {
								// System.out.println("Not skip this col(" + i + ")" + " or row(" + j + ")");
								// find the max num
								if (wordSimMatrix[i][j] > max) {
									max = wordSimMatrix[i][j];
									// System.out.println("maxChangedInto=" + max);
									tempDeli = i;
									tempDelj = j;
								}
							}
						}
					}
				}
				// after find the max num
				delListi.add(tempDeli);
				delListj.add(tempDelj);
				// System.out.println("delListi=" + delListi);
				// System.out.println("delListj=" + delListj);

				if (max >= threshold) {
					match++;
				}
				max = 0;
				// System.out.println("max=0");

			}

			s = match / smallerSize;

			// verify cde1 and cde2 are not the same
			// System.out.println("NotSameCde:cde1-"+cde1+" and "+"cde2-"+cde2);
			// System.out.println("match=" + match);
			// System.out.println("smaller size=" + smallerSize);
			// System.out.println("s=" + s);
		}

		// System.out.println("Finish processing two cde property-----------");
		return s;
	}

	public void gradientDescent() {
		double deltaw1, deltaw2, deltaw3, deltaw4, deltaw5, deltaw6;
		double error = 0;

		List trainClsList = trainCls();
		// System.out.println(trainClsList.size());

		for (int i = 1; i <= iterationTimes; i++) {

			// System.out.println("iterationTimes: " + i);

			deltaw1 = 0;
			deltaw2 = 0;
			deltaw3 = 0;
			deltaw4 = 0;
			deltaw5 = 0;
			deltaw6 = 0;
			double sCls1 = 0, sCls2 = 0, sCls3 = 0, sCls4 = 0, sCls5 = 0, sCls6 = 0, sCls = 0; // input values to our
																								// ANNs
			double sAvg1 = 0, sAvg2 = 0, sAvg3 = 0, sAvg4 = 0, sAvg5 = 0, sAvg6 = 0, sAvg = 0; // input values to our
																								// ANNs
			double sOtherCls1 = 0, sOtherCls2 = 0, sOtherCls3 = 0, sOtherCls4 = 0, sOtherCls5 = 0, sOtherCls6 = 0,
					sOtherCls = 0; // input values to our ANNs
			double sOtherAvg1 = 0, sOtherAvg2 = 0, sOtherAvg3 = 0, sOtherAvg4 = 0, sOtherAvg5 = 0, sOtherAvg6 = 0,
					sOtherAvg = 0;

			error = 0;

			// traverse each trainCls
			for (int n = 0; n <= (trainClsList.size() - 1); n++) {
				int samenum = 0;
				int notsamenum = 0;
				int firstEleFromClsNo = 0;// default 0
				boolean notHavFirseElmtNo = true;

				deltaw1 = 0;
				deltaw2 = 0;
				deltaw3 = 0;
				deltaw4 = 0;
				deltaw5 = 0;
				deltaw6 = 0;

				sAvg = 0;
				sAvg1 = 0;
				sAvg2 = 0;
				sAvg3 = 0;
				sAvg4 = 0;
				sAvg5 = 0;
				sAvg6 = 0;

				sOtherAvg = 0;
				sOtherAvg1 = 0;
				sOtherAvg2 = 0;
				sOtherAvg3 = 0;
				sOtherAvg4 = 0;
				sOtherAvg5 = 0;
				sOtherAvg6 = 0;
				// System.out.println("Start class " + (n + 1) + ":" + trainClsList.get(n));

				// find the num of class's first element
				for (int k = 1; k <= 1232; k++) {
					if (trainClsList.get(n).equals(CDEParserGetMatrix.CDEMatrix[7][k])) {
						if (notHavFirseElmtNo == true) {
							firstEleFromClsNo = k;
							notHavFirseElmtNo = false;
							break;
						}
					}
				}

				// traverse each element
				for (int j = 1; j <= 1232; j++) {
					// Similarity from this class
					if (trainClsList.get(n).equals(CDEParserGetMatrix.CDEMatrix[7][j])) {
						samenum++;
						// Don't take the class's first element into account
						if (!(j == firstEleFromClsNo)) {

							List oneCdeSfromCls = getSimilarity(firstEleFromClsNo, j);

							sCls1 = ((Double) oneCdeSfromCls.get(0));
							sCls2 = ((Double) oneCdeSfromCls.get(1));
							sCls3 = ((Double) oneCdeSfromCls.get(2));
							sCls4 = ((Double) oneCdeSfromCls.get(3));
							sCls5 = ((Double) oneCdeSfromCls.get(4));
							sCls6 = ((Double) oneCdeSfromCls.get(5));

							sCls = sCls1 * w1 + sCls2 * w2 + sCls3 * w3 + sCls4 * w4 + sCls5 * w5 + sCls6 * w6;

							sAvg += sCls;
							sAvg1 += sCls1;
							sAvg2 += sCls2;
							sAvg3 += sCls3;
							sAvg4 += sCls4;
							sAvg5 += sCls5;
							sAvg6 += sCls6;
						}

						// Similarity from other classes
						//find in the past doesn't contain (trainClsList.contains(CDEParserGetMatrix.CDEMatrix[7][j])), which is bad
					} else if(trainClsList.contains(CDEParserGetMatrix.CDEMatrix[7][j])){
						notsamenum++;
						List oneCdeSfromOtherCls = getSimilarity(firstEleFromClsNo, j);
						sOtherCls1 = ((Double) oneCdeSfromOtherCls.get(0));
						sOtherCls2 = ((Double) oneCdeSfromOtherCls.get(1));
						sOtherCls3 = ((Double) oneCdeSfromOtherCls.get(2));
						sOtherCls4 = ((Double) oneCdeSfromOtherCls.get(3));
						sOtherCls5 = ((Double) oneCdeSfromOtherCls.get(4));
						sOtherCls6 = ((Double) oneCdeSfromOtherCls.get(5));
						sOtherCls = sOtherCls1 * w1 + sOtherCls2 * w2 + sOtherCls3 * w3 + sOtherCls4 * w4
								+ sOtherCls5 * w5 + sOtherCls6 * w6;

						sOtherAvg += sOtherCls;
						sOtherAvg1 += sOtherCls1;
						sOtherAvg2 += sOtherCls2;
						sOtherAvg3 += sOtherCls3;
						sOtherAvg4 += sOtherCls4;
						sOtherAvg5 += sOtherCls5;
						sOtherAvg6 += sOtherCls6;
					}

				}
				sAvg /= (samenum - 1);
				sAvg1 /= (samenum - 1);
				sAvg2 /= (samenum - 1);
				sAvg3 /= (samenum - 1);
				sAvg4 /= (samenum - 1);
				sAvg5 /= (samenum - 1);
				sAvg6 /= (samenum - 1);

				sOtherAvg /= notsamenum;
				sOtherAvg1 /= notsamenum;
				sOtherAvg2 /= notsamenum;
				sOtherAvg3 /= notsamenum;
				sOtherAvg4 /= notsamenum;
				sOtherAvg5 /= notsamenum;
				sOtherAvg6 /= notsamenum;

				double sBig = sAvg > sOtherAvg ? sAvg : sOtherAvg;

				if (errorV1 == false) {
					// error version1 lisy
					deltaw1 = learningRate * (sBig - sAvg) * sAvg1;
					deltaw2 = learningRate * (sBig - sAvg) * sAvg2;
					deltaw3 = learningRate * (sBig - sAvg) * sAvg3;
					deltaw4 = learningRate * (sBig - sAvg) * sAvg4;
					deltaw5 = learningRate * (sBig - sAvg) * sAvg5;
					deltaw6 = learningRate * (sBig - sAvg) * sAvg6;

				} else {
					// error version2 dr.huang
					deltaw1 = learningRate * (target_v2Only - (sAvg - sOtherAvg) / sAvg) * sAvg1;
					deltaw2 = learningRate * (target_v2Only - (sAvg - sOtherAvg) / sAvg) * sAvg2;
					deltaw3 = learningRate * (target_v2Only - (sAvg - sOtherAvg) / sAvg) * sAvg3;
					deltaw4 = learningRate * (target_v2Only - (sAvg - sOtherAvg) / sAvg) * sAvg4;
					deltaw5 = learningRate * (target_v2Only - (sAvg - sOtherAvg) / sAvg) * sAvg5;
					deltaw6 = learningRate * (target_v2Only - (sAvg - sOtherAvg) / sAvg) * sAvg6;

				}

				w1 += deltaw1;
				w2 += deltaw2;
				w3 += deltaw3;
				w4 += deltaw4;
				w5 += deltaw5;
				w6 += deltaw6;

				if (errorV1 == false) {
					// E version1, lisy version
					error += (sBig - sAvg) * (sBig - sAvg) * 0.5;
				} else {
					// E version2, Dr. Huang version
					error += (target_v2Only - (sAvg - sOtherAvg) / sAvg) * (target_v2Only - (sAvg - sOtherAvg) / sAvg) * 0.5;

					// System.out.println("sAvg="+sAvg+"sOtherAvg"+sOtherAvg+" e="+error);
				}
				// System.out.println("Finish class " + (n + 1) + ":" + trainClsList.get(n));
			}

			// normalize the weights so that they sum to 1
			double tmp = w1 + w2 + w3 + w4 + w5 + w6;
			w1 /= tmp;
			w2 /= tmp;
			w3 /= tmp;
			w4 /= tmp;
			w5 /= tmp;
			w6 /= tmp;

			System.out.println("-----iterationTimes finish: " + i);
			System.out.println("sAvg=" + sAvg + " sOtherAvg" + sOtherAvg);

			System.out.println("error: " + error);
			errorking=error;

			System.out.println("w1: " + w1);
			System.out.println("w2: " + w2);
			System.out.println("w3: " + w3);
			System.out.println("w4: " + w4);
			System.out.println("w5: " + w5);
			System.out.println("w6: " + w6);

			/*
			 * if (i == 50 || i == 80 || i == 100 || i == 200 || i == 500 || i == 1000) {
			 * System.out.println("iterationTimes finish: " + i);
			 * System.out.println("sAvg="+sAvg+"sOtherAvg"+sOtherAvg);
			 * 
			 * System.out.println("error: " + error);
			 * 
			 * System.out.println("w1: " + w1); System.out.println("w2: " + w2);
			 * System.out.println("w3: " + w3); System.out.println("w4: " + w4);
			 * System.out.println("w5: " + w5); System.out.println("w6: " + w6);
			 * 
			 * } iteration time test
			 */
		}
	}

	public static void verification(double wtest1, double wtest2, double wtest3, double wtest4, double wtest5,
			double wtest6) {

		double sCls1 = 0, sCls2 = 0, sCls3 = 0, sCls4 = 0, sCls5 = 0, sCls6 = 0, sCls = 0; // input values to our
																							// ANNs
		double sAvg1 = 0, sAvg2 = 0, sAvg3 = 0, sAvg4 = 0, sAvg5 = 0, sAvg6 = 0, sAvg = 0; // input values to our
																							// ANNs
		double sOtherCls1 = 0, sOtherCls2 = 0, sOtherCls3 = 0, sOtherCls4 = 0, sOtherCls5 = 0, sOtherCls6 = 0,
				sOtherCls = 0; // input values to our ANNs
		double sOtherAvg1 = 0, sOtherAvg2 = 0, sOtherAvg3 = 0, sOtherAvg4 = 0, sOtherAvg5 = 0, sOtherAvg6 = 0,
				sOtherAvg = 0;
		System.out.println("-------------verification");
		double total = 0;

		//double correct = 0;

		List<Integer> correct = new ArrayList<Integer>();
		for(int i=0;i<=topN;i++) {
			correct.add(i,0);
		}
		
		double verification = 0;

		List trainClsList = trainCls();

		System.out.println("trainClsList.size()=" + trainClsList.size());
		// total=the count of class have more or equals to 2
		for (int n = 1; n <= 1232; n++) {
			if (trainClsList.contains(CDEParserGetMatrix.CDEMatrix[7][n])) {
				total++;
			}
		}
		total = total - trainClsList.size();
		System.out.println("total Denominator=" + total);

		// traverse each class's
		for (int n = 0; n <= (trainClsList.size() - 1); n++) {
			// every elmt
			for (int nstElmtOfSameCls = 2; nstElmtOfSameCls <= 291; nstElmtOfSameCls++) {
				double samenum = 0;
				double notsamenum = 0;
				int currentEleFromClsNo = 0;// default 0
				int count = 0;

				sAvg = 0;
				sAvg1 = 0;
				sAvg2 = 0;
				sAvg3 = 0;
				sAvg4 = 0;
				sAvg5 = 0;
				sAvg6 = 0;

				sOtherAvg = 0;
				sOtherAvg1 = 0;
				sOtherAvg2 = 0;
				sOtherAvg3 = 0;
				sOtherAvg4 = 0;
				sOtherAvg5 = 0;
				sOtherAvg6 = 0;

				// skip those don't have nstElmtOfSameCls(has less than stElmtOfSameCls elmt in
				// this cls)
				for (int k = 1; k <= 1232; k++) {
					if (trainClsList.get(n).equals(CDEParserGetMatrix.CDEMatrix[7][k])) {
						if (count < nstElmtOfSameCls) {
							currentEleFromClsNo = k;
							count++;
						}
					}
				}
				if (count < nstElmtOfSameCls) {
					continue;
				}

				//System.out.println("currentEleFromClsNo="+currentEleFromClsNo);
				
				// initialization
				List<Double> sAvgL = new ArrayList<Double>();
				List<Double> sOtherAvgL = new ArrayList<Double>();
				List<String> clsOf_sAvgs_sOtherAvgL = new ArrayList<String>();
				sAvgL.clear();
				sOtherAvgL.clear();
				//System.out.println(sAvgL);
				//System.out.println(sOtherAvgL);
				
				double max_sAvg, sOtherAvgOf_max_sAvg = 0;

				// calculate sAvg and sOtherAvg of each cls
				for (int i = 0; i <= (trainClsList.size() - 1); i++) {
					//System.out.println("Calculating sAvg and sOtherAvg of element[" + " nstElmtOfSameCls="
						//	+ nstElmtOfSameCls + " in ReallyCls="  + CDEParserGetMatrix.CDEMatrix[7][currentEleFromClsNo]
						//	+ "] in (i+1)=" + (i + 1) + " th cls " + trainClsList.get(i));
					//System.out.println("i="+i);
					
					// into one class, traverse each elmt
					for (int j = 1; j <= 1232; j++) {
						//System.out.println("j="+j);
						
						// Same cls as current cls traversed on
						if (trainClsList.get(i).equals(CDEParserGetMatrix.CDEMatrix[7][j])) {
							//System.out.println("trainClsList.get(i)="+trainClsList.get(i));
							//System.out.println("CDEParserGetMatrix.CDEMatrix[7][j]="+CDEParserGetMatrix.CDEMatrix[7][j]);
							
							if (!(j == currentEleFromClsNo)) {
								//System.out.println("j="+j);
								//System.out.println("currentEleFromClsNo="+currentEleFromClsNo);
								
								List oneCdeSfromCls = getSimilarity(currentEleFromClsNo, j);
								//System.out.println("oneCdeSfromCls="+oneCdeSfromCls);
								
								samenum++;

								sCls1 = (Double) oneCdeSfromCls.get(0);
								sCls2 = (Double) oneCdeSfromCls.get(1);
								sCls3 = (Double) oneCdeSfromCls.get(2);
								sCls4 = (Double) oneCdeSfromCls.get(3);
								sCls5 = (Double) oneCdeSfromCls.get(4);
								sCls6 = (Double) oneCdeSfromCls.get(5);

								sCls = sCls1 * wtest1 + sCls2 * wtest2 + sCls3 * wtest3 + sCls4 * wtest4
										+ sCls5 * wtest5 + sCls6 * wtest6;

								sAvg += sCls;
							}

							// Not same cls as current cls traversed on
						} else {

							notsamenum++;
							List oneCdeSfromOtherCls = getSimilarity(currentEleFromClsNo, j);

							sOtherCls1 = (Double) oneCdeSfromOtherCls.get(0);
							sOtherCls2 = (Double) oneCdeSfromOtherCls.get(1);
							sOtherCls3 = (Double) oneCdeSfromOtherCls.get(2);
							sOtherCls4 = (Double) oneCdeSfromOtherCls.get(3);
							sOtherCls5 = (Double) oneCdeSfromOtherCls.get(4);
							sOtherCls6 = (Double) oneCdeSfromOtherCls.get(5);

							sOtherCls = sOtherCls1 * w1 + sOtherCls2 * w2 + sOtherCls3 * w3 + sOtherCls4 * w4
									+ sOtherCls5 * w5 + sOtherCls6 * w6;

							sOtherAvg += sOtherCls;
						}

					}

					// Calculate sAvg and sOtherAvg of this cls
					sAvg /= (samenum - 1);
					sAvgL.add(sAvg);
					//System.out.println("0-adding-.sAvgL="+sAvgL);
					
					sOtherAvg /= notsamenum;
					sOtherAvgL.add(sOtherAvg);
					//System.out.println("sOtherAvgL.size()="+sOtherAvgL.size());

					clsOf_sAvgs_sOtherAvgL.add((String) trainClsList.get(i));
					//System.out.println("clsOf_sAvgs_sOtherAvgL.size()="+clsOf_sAvgs_sOtherAvgL.size());
				
				}

				// find the max sAvg from sAvgL, if sAvg>sOtherAvg,output true
				max_sAvg = Collections.max(sAvgL);
				//System.out.println("max_sAvg="+max_sAvg);

				int indexNum = 0;

				for (int indexi = 0; indexi <= sAvgL.size() - 1; indexi++) {
						if(sAvgL.get(indexi).equals(Collections.max(sAvgL))){
							if1notbad++;
						}
				}
				
				// how to deal with two same biggest num?
				for (int index = 0; index <= sAvgL.size() - 1; index++) {
					if (sAvgL.get(index) == max_sAvg) {
						indexNum = index;
					}
				}

				// sOtherAvgOf_max_sAvg=sOtherAvgL.get(indexNum);

				max_sAvg_LargerThan_sOtherAvg=(max_sAvg>sOtherAvgOf_max_sAvg)?true:false;

				// if the max similarity is correctly at what class it belongs to
				////li System.out.println("CDEParserGetMatrix.CDEMatrix[7]["+currentEleFromClsNo+"]="+CDEParserGetMatrix.CDEMatrix[7][currentEleFromClsNo]);
				////li System.out.println("clsOf_sAvgs_sOtherAvgL.get("+indexNum+")"+clsOf_sAvgs_sOtherAvgL.get(indexNum));
				
				
				//TopN
				//sAvgL, sOtherAvgL, clsOf_sAvgs_sOtherAvgL
				
				
					List<String> topList = new ArrayList<String>();
					//List<Double> tempDeletableSimAvgL = sAvgL;
					List<Double> tempDeletableSimAvgL = new ArrayList<Double>(sAvgL);

					

					//System.out.println("1.sAvgL="+sAvgL);
					//System.out.println("1.tempDeletableSimAvgL="+tempDeletableSimAvgL);
				
				for(int j=1;j<=topN;j++) {
					topList.clear();
					tempDeletableSimAvgL.clear();	
					tempDeletableSimAvgL =  new ArrayList<Double>(sAvgL);
					

					//System.out.println("2.sAvgL="+sAvgL);
					//System.out.println("2.tempDeletableSimAvgL="+tempDeletableSimAvgL);
					
					//List<Double> lalala= new ArrayList<Double>();
					//lalala.add((double) 1);
					//lalala.add((double) 2);
					//lalala.add((double) 3);
					//tempDeletableSimAvgL.add((double) 3);
					
					//System.out.println("lalala"+lalala.get(1));
					double tempMax_sAvg=0;		
					//System.out.println("lalala"+tempDeletableSimAvgL.get(0));
					tempMax_sAvg = Collections.max(tempDeletableSimAvgL);
					
					for(int i=1;i<=j;i++) {
						
						tempMax_sAvg = Collections.max(tempDeletableSimAvgL);
						int ind=tempDeletableSimAvgL.indexOf(tempMax_sAvg);
						topList.add(clsOf_sAvgs_sOtherAvgL.get(ind));
						tempDeletableSimAvgL.set(ind, 0.0);
					}
					
					if(topList.contains(CDEParserGetMatrix.CDEMatrix[7][currentEleFromClsNo])) {
						correct.set(j, correct.get(j)+1);
					}
				}
				//if (CDEParserGetMatrix.CDEMatrix[7][currentEleFromClsNo].equals(clsOf_sAvgs_sOtherAvgL.get(indexNum))) {
				//	correct++;
				//}

				//System.out.println("total Denominator=" + total);
			}
		}

		for(int i=1;i<=topN;i++) {
			System.out.print("All weights" + "	" + wtest1 + "	" + wtest2 + "	" + wtest3 + "	" + wtest4 + "	" + wtest5
					+ "	" + wtest6);
	
			System.out.print("	" + "verification=" + "	" + (correct.get(i) / total) + "	" + "correct=" + "	" + correct.get(i) + "	"
					+ "total=" + "	" + total+"	"+"max_sAvg_LargerThan_sOtherAvg="+"	"+max_sAvg_LargerThan_sOtherAvg);
	
			System.out.print("	iterationTimes=" + "	" + iterationTimes);
			System.out.print("	errorVersion=" + "	"
					+ ((errorV1) ? "errorVersion2=(target-(sAvg-sOtherAvg)/sAvg)*(target-(sAvg-sOtherAvg)/sAvg)*0.5"
							: "errorVersion1=(sBig - sAvg)*(sBig - sAvg)/2"));
			System.out.print("	error=" + "	" + errorking);
			System.out.print("	similarity threshold=" + "	" + threshold);
			System.out.print("	target_v2Only=" + "	" + target_v2Only);
			System.out.print("	topN=" + "	" + i);
			System.out.println("	if1notbad="+"	"+if1notbad);
		}
		
		
	}
	/*
	 * verification backup public static void verification(double wtest1, double
	 * wtest2, double wtest3, double wtest4, double wtest5, double wtest6) {
	 * 
	 * double sCls1 = 0, sCls2 = 0, sCls3 = 0, sCls4 = 0, sCls5 = 0, sCls6 = 0, sCls
	 * = 0; // input values to our // ANNs double sAvg1 = 0, sAvg2 = 0, sAvg3 = 0,
	 * sAvg4 = 0, sAvg5 = 0, sAvg6 = 0, sAvg = 0; // input values to our // ANNs
	 * double sOtherCls1 = 0, sOtherCls2 = 0, sOtherCls3 = 0, sOtherCls4 = 0,
	 * sOtherCls5 = 0, sOtherCls6 = 0, sOtherCls = 0; // input values to our ANNs
	 * double sOtherAvg1 = 0, sOtherAvg2 = 0, sOtherAvg3 = 0, sOtherAvg4 = 0,
	 * sOtherAvg5 = 0, sOtherAvg6 = 0, sOtherAvg = 0;
	 * System.out.println("-------------verification");
	 * 
	 * if (errorV1 == false) { // error version1 lisy
	 * System.out.println("This is version1 lisy");
	 * System.out.println("Error=(sBig - sAvg)*(sBig - sAvg)/2"); } else { // error
	 * version2 dr.huang System.out.println("This is version2 dr.huang");
	 * System.out.println(
	 * "Error=(1-(sAvg-sOtherAvg)/sAvg)*(1-(sAvg-sOtherAvg)/sAvg)*0.5"); }
	 * 
	 * List trainClsList = trainCls(); // System.out.println(trainClsList.size());
	 * 
	 * for (int n = 0; n <= (trainClsList.size() - 1); n++) { double correct = 0;
	 * double verification = 0; double total = 0;
	 * 
	 * for (int nstElmtOfSameCls = 2; nstElmtOfSameCls <= 291; nstElmtOfSameCls++) {
	 * double samenum = 0; double notsamenum = 0; int currentEleFromClsNo = 0;//
	 * default 0 int count = 0;
	 * 
	 * sAvg = 0; sAvg1 = 0; sAvg2 = 0; sAvg3 = 0; sAvg4 = 0; sAvg5 = 0; sAvg6 = 0;
	 * 
	 * sOtherAvg = 0; sOtherAvg1 = 0; sOtherAvg2 = 0; sOtherAvg3 = 0; sOtherAvg4 =
	 * 0; sOtherAvg5 = 0; sOtherAvg6 = 0;
	 * 
	 * 
	 * for (int k = 1; k <= 1232; k++) { if
	 * (trainClsList.get(n).equals(CDEParserGetMatrix.CDEMatrix[7][k])) { if (count
	 * < nstElmtOfSameCls) { currentEleFromClsNo = k; count++; } } } if (count <
	 * nstElmtOfSameCls) { continue; }
	 * 
	 * // System.out.println("test1: "+sOtherAvg); for (int j = 1; j <= 1232; j++) {
	 * // Similarity from this class if
	 * (trainClsList.get(n).equals(CDEParserGetMatrix.CDEMatrix[7][j])) {
	 * 
	 * samenum++; if (!(j == currentEleFromClsNo)) { List oneCdeSfromCls =
	 * getSimilarity(currentEleFromClsNo, j);
	 * 
	 * // System.out.println("getSimilarity(currentEleFromClsNo, //
	 * j)="+getSimilarity(currentEleFromClsNo, j));
	 * 
	 * sCls1 = (Double) oneCdeSfromCls.get(0); sCls2 = (Double)
	 * oneCdeSfromCls.get(1); sCls3 = (Double) oneCdeSfromCls.get(2); sCls4 =
	 * (Double) oneCdeSfromCls.get(3); sCls5 = (Double) oneCdeSfromCls.get(4); sCls6
	 * = (Double) oneCdeSfromCls.get(5);
	 * 
	 * sCls = sCls1 * wtest1 + sCls2 * wtest2 + sCls3 * wtest3 + sCls4 * wtest4 +
	 * sCls5 * wtest5 + sCls6 * wtest6;
	 * 
	 * sAvg += sCls; }
	 * 
	 * // Similarity from other classes } else { notsamenum++; List
	 * oneCdeSfromOtherCls = getSimilarity(currentEleFromClsNo, j); sOtherCls1 =
	 * (Double) oneCdeSfromOtherCls.get(0); sOtherCls2 = (Double)
	 * oneCdeSfromOtherCls.get(1); sOtherCls3 = (Double) oneCdeSfromOtherCls.get(2);
	 * sOtherCls4 = (Double) oneCdeSfromOtherCls.get(3); sOtherCls5 = (Double)
	 * oneCdeSfromOtherCls.get(4); sOtherCls6 = (Double) oneCdeSfromOtherCls.get(5);
	 * sOtherCls = sOtherCls1 * w1 + sOtherCls2 * w2 + sOtherCls3 * w3 + sOtherCls4
	 * * w4 + sOtherCls5 * w5 + sOtherCls6 * w6;
	 * 
	 * sOtherAvg += sOtherCls; }
	 * 
	 * } // calculate every zonghe s then average // or // calculate the avg of each
	 * similarity then times these weights sAvg /= (samenum - 1);
	 * 
	 * sOtherAvg /= notsamenum;
	 * 
	 * total++; if (sAvg >= sOtherAvg) { correct++;
	 * System.out.println("nstElmtOfSameCls=	" + nstElmtOfSameCls + "	" +
	 * "verfied=" + "	" + "true"); } else {
	 * System.out.println("nstElmtOfSameCls=	" + nstElmtOfSameCls + "	" +
	 * "verfied=" + "	" + "false"); }
	 * 
	 * } verification = correct / total; System.out.print("All weights" + "	" +
	 * wtest1 + "	" + wtest2 + "	" + wtest3 + "	" + wtest4 + "	" + wtest5 +
	 * "	" + wtest6); System.out.print("	" + "This element is in Class" + "	" +
	 * (n + 1) + "	" + ":" + "	" + trainClsList.get(n)); System.out.print("	" +
	 * "verification=" + "	" + verification + "	" + "correct=" + "	" + correct
	 * + "	" + "total=" + "	" + total);
	 * 
	 * System.out.print("	iterationTimes="+"	"+iterationTimes);
	 * System.out.print("	errorVersion="+"	"+((errorV1)?"errorVersion2":
	 * "errorVersion1")); System.out.print("	threshold="+"	"+threshold); }
	 * 
	 * }
	 */

	public static List getSimilarity(int i, int j) {
		List sim = new ArrayList();
		String sValue = new String();
		String tmp1 = new String();
		String tmp2 = new String();
		String tmp3 = new String();
		String tmp4 = new String();
		String tmp5 = new String();
		String tmp6 = new String();
		int ind;

		// sValue = ((String) simMatrixComp[i+1][j]).trim();
		sValue = ((String) simMatrixComp[i][j]).trim();

		ind = sValue.indexOf("#");
		tmp1 = sValue.substring(0, ind);
		sValue = sValue.substring(ind + 1);

		ind = sValue.indexOf("#");
		tmp2 = sValue.substring(0, ind);
		sValue = sValue.substring(ind + 1);

		ind = sValue.indexOf("#");
		tmp3 = sValue.substring(0, ind);
		sValue = sValue.substring(ind + 1);

		ind = sValue.indexOf("#");
		tmp4 = sValue.substring(0, ind);
		sValue = sValue.substring(ind + 1);

		ind = sValue.indexOf("#");
		tmp5 = sValue.substring(0, ind);

		tmp6 = sValue.substring(ind + 1);

		sim.add(new Double(tmp1));
		sim.add(new Double(tmp2));
		sim.add(new Double(tmp3));
		sim.add(new Double(tmp4));
		sim.add(new Double(tmp5));
		sim.add(new Double(tmp6));

		return sim;
	}

	public static List<String> trainCls() {
		List<String> trainclslist = new ArrayList<String>(); // list of classes contain more than one CDEs

		/*
		trainClsList.add("PerformedClinicalResult");
		trainClsList.add("PerformedDiagnosis");
		trainClsList.add("PerformedObservation");
		trainClsList.add("PerformedObservationResult");
		trainClsList.add("PerformedSubstanceAdministration");
		trainClsList.add("PerformedProcedure");
		trainClsList.add("MaterialName");
		trainClsList.add("TargetAnatomicSite");
		trainClsList.add("PerformedClinicalInterpretation");
		trainClsList.add("DefinedProcedure");
		trainClsList.add("DefinedObservation");
		trainClsList.add("Person");
		trainClsList.add("Organization");
		trainClsList.add("PerformedMedicalConditionResult");
		trainClsList.add("DefinedSubstanceAdministration");
		trainClsList.add("ReferenceResult");
		trainClsList.add("SubstanceExtractionAdministrationRelationship");
		trainClsList.add("BiologicEntityIdentifier");
		trainClsList.add("BiologicEntity");
		trainClsList.add("Product");
		trainClsList.add("Animal");
		trainClsList.add("OrganizationIdentifier");
		trainClsList.add("PerformedLesionDescription");
		trainClsList.add("HealthCareFacility");
		trainClsList.add("PerformedProductTransport");
		trainClsList.add("DefinedMaterialProcessStep");
		trainClsList.add("SubjectIdentifier");
		trainClsList.add("PerformedMedicalCondition");
		trainClsList.add("PerformedSubstanceExtraction");
		trainClsList.add("PerformedStudySubjectMilestone");
		trainClsList.add("PerformedMaterialProcessStep");
		trainClsList.add("PerformedAdministrativeActivity");
		trainClsList.add("Performer");
		trainClsList.add("AssociatedBiologicEntity");// amount3
		trainClsList.add("PerformedMaterialStorage");
		trainClsList.add("Specimen");// amount2
		trainClsList.add("DefinedMaterialStorage");
		trainClsList.add("AdverseEvent");
		trainClsList.add("StudySitePersonnel");
		trainClsList.add("DocumentIdentifier");
		trainClsList.add("MaterialIdentifier");
		trainClsList.add("DefinedActivity");
		trainClsList.add("PerformedSpecimenCollection");
		trainClsList.add("PerformedImaging");
		*/
		trainclslist.add("performedclinicalresult");
		trainclslist.add("performeddiagnosis");
		trainclslist.add("performedobservation");
		trainclslist.add("performedobservationresult");
		trainclslist.add("performedsubstanceadministration");
		trainclslist.add("performedprocedure");
		trainclslist.add("materialname");
		trainclslist.add("targetanatomicsite");
		trainclslist.add("performedclinicalinterpretation");
		trainclslist.add("definedprocedure");
		trainclslist.add("definedobservation");
		trainclslist.add("person");
		trainclslist.add("organization");
		trainclslist.add("performedmedicalconditionresult");
		trainclslist.add("definedsubstanceadministration");
		trainclslist.add("referenceresult");
		trainclslist.add("substanceextractionadministrationrelationship");
		trainclslist.add("biologicentityidentifier");
		trainclslist.add("biologicentity");
		trainclslist.add("product");
		trainclslist.add("animal");
		trainclslist.add("organizationidentifier");
		trainclslist.add("performedlesiondescription");
		trainclslist.add("healthcarefacility");
		trainclslist.add("performedproducttransport");
		trainclslist.add("definedmaterialprocessstep");
		trainclslist.add("subjectidentifier");
		trainclslist.add("performedmedicalcondition");
		
		trainclslist.add("performedsubstanceextraction");
		trainclslist.add("performedstudysubjectmilestone");
		trainclslist.add("performedmaterialprocessstep");
		trainclslist.add("performedadministrativeactivity");
		trainclslist.add("performer");
		trainclslist.add("associatedbiologicentity");// amount3
		trainclslist.add("performedmaterialstorage");
		trainclslist.add("specimen");// amount2
		trainclslist.add("definedmaterialstorage");
		trainclslist.add("adverseevent");
		trainclslist.add("studysitepersonnel");
		trainclslist.add("documentidentifier");
		trainclslist.add("materialidentifier");
		trainclslist.add("definedactivity");
		trainclslist.add("performedspecimencollection");
		trainclslist.add("performedimaging");
		
		return trainclslist;
	}

	// A Dynamic Programming based Java program to find minimum
	// number operations to convert str1 to str2
	/* This code is contributed by Rajat Mishra */
	static int min(int x, int y, int z) {
		if (x <= y && x <= z)
			return x;
		if (y <= x && y <= z)
			return y;
		else
			return z;
	}

	static int editDistDP(String str1, String str2, int m, int n) {
		// Create a table to store results of subproblems
		int dp[][] = new int[m + 1][n + 1];

		// Fill d[][] in bottom up manner
		for (int i = 0; i <= m; i++) {
			for (int j = 0; j <= n; j++) {
				// If first string is empty, only option is to
				// isnert all characters of second string
				if (i == 0)
					dp[i][j] = j; // Min. operations = j

				// If second string is empty, only option is to
				// remove all characters of second string
				else if (j == 0)
					dp[i][j] = i; // Min. operations = i

				// If last characters are same, ignore last char
				// and recur for remaining string
				else if (str1.charAt(i - 1) == str2.charAt(j - 1))
					dp[i][j] = dp[i - 1][j - 1];

				// If last character are different, consider all
				// possibilities and find minimum
				else
					dp[i][j] = 1 + min(dp[i][j - 1], // Insert
							dp[i - 1][j], // Remove
							dp[i - 1][j - 1]); // Replace
			}
		}

		return dp[m][n];
	}

}
