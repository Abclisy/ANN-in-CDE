import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

//modified by lisy - into 1232x1232 example
/**
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: USC</p>
 * @author Jingshan Huang
 * @version 1.0
 */

public class DeltaRule12321232runnableBackup { 
	public long ou=0;
  public String[][] simVecMatrix; // each cell is a string (e.g. "0.85#0.27#0.56"), recording the similarity values for 2 concepts in 3 dimensions (name, property, and ancestor)
  public double[][] simMatrix; // similarity matrix recalculated using the learned weights
  public int iterationTimes = 10; // how many iterations in running Delta Rule algorithm, will try 10, 15, 20, 30, 50, 80, 100, 200, 500, 1000, 1500, 2500, and 5000.
  public double learningRate = 0.05; // will try 0.05, 0.1, and 0.2
  public double w1 = 1.0/6, w2 = 1.0/6, w3 = 1.0/6, w4 = 1.0/6, w5 = 1.0/6, w6 = 1.0/6; // initialize three weights (for name, property, and ancestor)
  //public List trainingExamples = new ArrayList(); // a set of training examples, each example contains 2 indexes (in the form of "i@j"), meaning ith and jth concepts are equivalent
  public static List trainingExamples = new ArrayList(); 
  
  public DeltaRule12321232runnableBackup(String[][] matrix) {
    setSimVecMatrix(matrix);
    //initSimMatrix(); // set up similarity matrix between 2 ontologies. Manually done at this point, will get input from new Puzzle program.
    getTrainingExamples();
    gradientDescent();
    //validate();
  }

  public void setSimVecMatrix(String[][] matrix){
    simVecMatrix = matrix;
    //System.out.println(simVecMatrix[0][0]);
    //System.exit(0);
  }

  public static void main(String[] args) {
	  	
	    String matrix[][]=new String[1233][1233];
		 
	    CDEParser12321232runnableBackup cdeparser = new CDEParser12321232runnableBackup();
	    //deltarule.setSimVecMatrix(matrix);
		
	    System.out.println("Started");
	    //CDEParser CDEAANN;
	    CDEParser12321232runnableBackup.outputCurrentTime("1. Start parsing xml files --- ");
	    CDEParser12321232runnableBackup.getXmlFiles();
	    if(CDEParser12321232runnableBackup.XMLFiles.isEmpty())
	    {
	    	System.err.println("No XML Files located" );
	    }
	    for(String s: CDEParser12321232runnableBackup.XMLFiles)
	    {
	    	System.out.println("the xml files are: "+ s);
	    	String file_Name= new String(s);
	    	CDEParser12321232runnableBackup.outputCurrentTime("Now parsing file:: "+file_Name);
	    	CDEParser12321232runnableBackup.generateXML(file_Name);
	    }
	    
	    CDEParser12321232runnableBackup.BridgList();
	    
	    for(String s1:CDEParser12321232runnableBackup.bridgList.keySet())
	    {
	    	System.out.println("BRIDG_Class::"+s1+"-->COUNT::"+CDEParser12321232runnableBackup.bridgList.get(s1).size());
	    }
	    
	    System.out.println("TOTAL BRIDGS--->"+CDEParser12321232runnableBackup.bridgList.size());
	    
	    int count=0;
	    
	    for(String s:CDEParser12321232runnableBackup.bridgList.keySet())
	    {
	    	if(CDEParser12321232runnableBackup.bridgList.get(s).size()>=10)
	    	{
	    		count++;
	    	}
	    }
	    System.out.println("BRIDGS with only 1 result===>"+count);

	    
	    //li sCDESimMatrix get Similarity
	    double s1,s2,s3,s4,s5,s6;
	    double d1,d2,d3,d4,d5,d6;
	    double l1,l2,l3,l4,l5,l6;
	    
	    //��һ�е�i��Ԫ�غ͵�һ�е�j��Ԫ��

	    for(int i = 1; i <= 1232; i = i+1) {
	    	for(int j = 1; j <= 1232; j = j+1) {
	    		
			    d1=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[1][i],CDEParser12321232runnableBackup.CDEMatrix[1][j]);
			    d2=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[2][i],CDEParser12321232runnableBackup.CDEMatrix[2][j]);
			    d3=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[3][i],CDEParser12321232runnableBackup.CDEMatrix[3][j]);
			    d4=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[4][i],CDEParser12321232runnableBackup.CDEMatrix[4][j]);
			    d5=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[5][i],CDEParser12321232runnableBackup.CDEMatrix[5][j]);
			    d6=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[6][i],CDEParser12321232runnableBackup.CDEMatrix[6][j]);
			    //l1=CDEMatrix[6][i]��CDEMatrix[6][j])�����ַ����ĳ���
			    l1=(CDEParser12321232runnableBackup.CDEMatrix[1][i].length()>CDEParser12321232runnableBackup.CDEMatrix[1][j].length())?CDEParser12321232runnableBackup.CDEMatrix[1][i].length():CDEParser12321232runnableBackup.CDEMatrix[1][j].length();
			    l2=(CDEParser12321232runnableBackup.CDEMatrix[2][i].length()>CDEParser12321232runnableBackup.CDEMatrix[2][j].length())?CDEParser12321232runnableBackup.CDEMatrix[2][i].length():CDEParser12321232runnableBackup.CDEMatrix[2][j].length();
			    l3=(CDEParser12321232runnableBackup.CDEMatrix[3][i].length()>CDEParser12321232runnableBackup.CDEMatrix[3][j].length())?CDEParser12321232runnableBackup.CDEMatrix[3][i].length():CDEParser12321232runnableBackup.CDEMatrix[3][j].length();
			    l4=(CDEParser12321232runnableBackup.CDEMatrix[4][i].length()>CDEParser12321232runnableBackup.CDEMatrix[4][j].length())?CDEParser12321232runnableBackup.CDEMatrix[4][i].length():CDEParser12321232runnableBackup.CDEMatrix[4][j].length();
			    l5=(CDEParser12321232runnableBackup.CDEMatrix[5][i].length()>CDEParser12321232runnableBackup.CDEMatrix[5][j].length())?CDEParser12321232runnableBackup.CDEMatrix[5][i].length():CDEParser12321232runnableBackup.CDEMatrix[5][j].length();
			    l6=(CDEParser12321232runnableBackup.CDEMatrix[6][i].length()>CDEParser12321232runnableBackup.CDEMatrix[6][j].length())?CDEParser12321232runnableBackup.CDEMatrix[6][i].length():CDEParser12321232runnableBackup.CDEMatrix[6][j].length();

			    s1=CDEParser12321232runnableBackup.CDEMatrix[1][i].equals(CDEParser12321232runnableBackup.CDEMatrix[1][j])?1:(1-d1/l1);
			    s2=CDEParser12321232runnableBackup.CDEMatrix[2][i].equals(CDEParser12321232runnableBackup.CDEMatrix[2][j])?1:(1-d2/l2);
			    s3=CDEParser12321232runnableBackup.CDEMatrix[3][i].equals(CDEParser12321232runnableBackup.CDEMatrix[3][j])?1:(1-d3/l3);
			    s4=CDEParser12321232runnableBackup.CDEMatrix[4][i].equals(CDEParser12321232runnableBackup.CDEMatrix[4][j])?1:(1-d4/l4);
			    s5=CDEParser12321232runnableBackup.CDEMatrix[5][i].equals(CDEParser12321232runnableBackup.CDEMatrix[5][j])?1:(1-d5/l5);
			    s6=CDEParser12321232runnableBackup.CDEMatrix[6][i].equals(CDEParser12321232runnableBackup.CDEMatrix[6][j])?1:(1-d6/l6);
			    
			    DecimalFormat df = new DecimalFormat("0.00");
			    s1=Double.parseDouble(df.format(s1));
			    s2=Double.parseDouble(df.format(s2));
			    s3=Double.parseDouble(df.format(s3));
			    s4=Double.parseDouble(df.format(s4));
			    s5=Double.parseDouble(df.format(s5));
			    s6=Double.parseDouble(df.format(s6));
			    
			    CDEParser12321232runnableBackup.CDESimMatrix[i][j]=(s1+"#"+s2+"#"+s3+"#"+s4+"#"+s5+"#"+s6);
			    //System.out.println(CDEParser.CDESimMatrix[i][j]);
			    
			    matrix[i][j] = CDEParser12321232runnableBackup.CDESimMatrix[i][j];
	    	}
	    }
	    /**/
	    
	    //get training example
	    for(int i = 1; i <= 1232; i = i+1) {
	    	for(int j = 1; j <= 1232; j = j+1) {
		    	//if(i>j) {j=i;}//get training example no replicated
				    if(CDEParser12321232runnableBackup.CDEMatrix[7][i].equals(CDEParser12321232runnableBackup.CDEMatrix[7][j])) {
		    		//System.out.println("trainingExamples"+"."+"add("+"\""+i+"@"+j+"\");");
		    		trainingExamples.add(i+"@"+j);
				    }
		    	
	    	}
	    }
	    /**/
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	  
 
    DeltaRule12321232runnableBackup deltarule = new DeltaRule12321232runnableBackup(matrix);
    //deltarule.setSimVecMatrix(matrix);
    //deltarule.initSimMatrix(); // set up similarity matrix between 2 ontologies. Manually done at this point, will get input from new Puzzle program.
    //deltarule.getTrainingExamples();
    //deltarule.gradientDescent();
    //deltarule.validate();

  }

  public void getTrainingExamples(){

	  
	//trainingExamples.add("1@1");

	
	  
  }

  public void gradientDescent(){
    double deltaw1, deltaw2, deltaw3, deltaw4, deltaw5, deltaw6;
    double error = 0; // training errors

    for(int i = 1; i <= iterationTimes; i ++){
      deltaw1 = 0;
      deltaw2 = 0;
      deltaw3 = 0;
      deltaw4 = 0;
      deltaw5 = 0;
      deltaw6 = 0;
      int row, col; // the indexes of the equivalent concepts in the similarity matrix
      double maxInRow = 0, maxInCol = 0; // the maximal value in the row of row and the column of col
      double output = 0; // the output value from our ANNs
      double x1 = 0, x2 = 0, x3 = 0, x4 = 0, x5 = 0, x6 = 0; // input values to our ANNs
      error = 0;
      String stmp1, stmp2;
      Integer itmp1, itmp2;

      for(int j = 0; j < trainingExamples.size(); j++){
        stmp1 = ((String)trainingExamples.get(j)).trim();
        stmp2 = stmp1.substring(stmp1.indexOf("@") + 1);
        stmp1 = stmp1.substring(0, stmp1.indexOf("@"));
        itmp1 = new Integer(stmp1);
        itmp2 = new Integer(stmp2);
        row = itmp1.intValue();
        col = itmp2.intValue();
        
        // obtain the input values
        List input = getSimilarity(row, col);
        x1 = ( (Double) input.get(0)).doubleValue();
        x2 = ( (Double) input.get(1)).doubleValue(); /* do NOT use properties for OBO; x2 will be 0.0 for all pairs 07/04/2007 */
        x3 = ( (Double) input.get(2)).doubleValue();
        x4 = ( (Double) input.get(3)).doubleValue();
        x5 = ( (Double) input.get(4)).doubleValue();
        x6 = ( (Double) input.get(5)).doubleValue();
        // calculate the output value
        output = x1 * w1 + x2 * w2 + x3 * w3 + x4 * w4 + x5 * w5 + x6 * w6; /* do NOT use properties for OBO 07/04/2007 */

        // find the maximal value in the row of row
        double c1, c2, c3, c4, c5, c6, sim; // temporary variables recording similarity values
        maxInRow = output;

        int c, maxRow = row;
        //li
        //for(c = 1; c <= 24; c ++){

        for(c = 1; c <= 1232; c ++){
          input = getSimilarity(row, c);
          c1 = ( (Double) input.get(0)).doubleValue();
          c2 = ( (Double) input.get(1)).doubleValue();
          c3 = ( (Double) input.get(2)).doubleValue();
          c4 = ( (Double) input.get(3)).doubleValue();
          c5 = ( (Double) input.get(4)).doubleValue();
          c6 = ( (Double) input.get(5)).doubleValue();
          sim = c1 * w1 + c2 * w2 + c3 * w3 + c4 * w4 + c5 * w5 + c6 * w6;

          if(sim > maxInRow) {
            maxRow = c;
            maxInRow = sim;
          }
        }

        // find the maximal value in the column of col
        double r1, r2, r3, r4, r5, r6, sim2; // temporary variables recording similarity values
        maxInCol = output;

        int r, maxCol = col;
        //for(r = 1; r <= 24; r ++){

        for(r = 1; r <= 1232; r ++){
          input = getSimilarity(r, col);
          r1 = ( (Double) input.get(0)).doubleValue();
          r2 = ( (Double) input.get(1)).doubleValue();
          r3 = ( (Double) input.get(2)).doubleValue();
          r4 = ( (Double) input.get(3)).doubleValue();
          r5 = ( (Double) input.get(4)).doubleValue();
          r6 = ( (Double) input.get(5)).doubleValue();
          sim = r1 * w1 + r2 * w2 + r3 * w3 + r4 * w4 + r5 * w5 + r6 * w6;

          if(sim > maxInCol) {
            maxCol = r;
            maxInCol = sim;
          }
        }

        // update deltawi
        deltaw1 += learningRate * ( (maxInRow - output) + (maxInCol - output)) *  x1;
        deltaw2 += learningRate * ( (maxInRow - output) + (maxInCol - output)) *  x2;
        deltaw3 += learningRate * ( (maxInRow - output) + (maxInCol - output)) *  x3;
        deltaw4 += learningRate * ( (maxInRow - output) + (maxInCol - output)) *  x4;
        deltaw5 += learningRate * ( (maxInRow - output) + (maxInCol - output)) *  x5;
        deltaw6 += learningRate * ( (maxInRow - output) + (maxInCol - output)) *  x6;

        // calculate training errors
        error += ((maxInRow - output) + (maxInCol - output)) * ((maxInRow - output) + (maxInCol - output))/2;
      }

      w1 += deltaw1;
      w2 += deltaw2;
      w3 += deltaw3;
      w4 += deltaw4;
      w5 += deltaw5;
      w6 += deltaw6;

      // normalize the weights so that they sum to 1
      double tmp = w1 + w2 + w3 + w4 + w5 + w6;
      w1 /= tmp;
      w2 /= tmp;
      w3 /= tmp;
      w4 /= tmp;
      w5 /= tmp;
      w6 /= tmp;
    }

    // the training error before the weights are updated
    System.out.println("Tranining Error: " + error);

    System.out.println("w1: " + w1);
    System.out.println("w2: " + w2);
    System.out.println("w3: " + w3);
    System.out.println("w4: " + w4);
    System.out.println("w5: " + w5);
    System.out.println("w6: " + w6);
  }

  public void validate(){
    int row, col;

    // recalculate the similarity matrix based on the learned weights
    //li
    //simMatrix = new double[25][25];
    simMatrix = new double[1233][1233];
    //New 
    //li
    //for(row = 1; row <= 24; row ++){
      //for (col = 1; col <= 24; col ++){
    for(row = 1; row <= 1232; row ++){
      for (col = 1; col <= 1232; col ++){
        List input = getSimilarity(row, col);
        double x1 = ( (Double) input.get(0)).doubleValue();
        double x2 = ( (Double) input.get(1)).doubleValue();
        double x3 = ( (Double) input.get(2)).doubleValue();
        double x4 = ( (Double) input.get(3)).doubleValue();
        double x5 = ( (Double) input.get(4)).doubleValue();
        double x6 = ( (Double) input.get(5)).doubleValue();

        simMatrix[row][col] = x1 * w1 + x2 * w2 + x3 * w3 + x4 * w4 + x5 * w5 + x6 * w6;
      }
    }

    // from the updated matrix, pick up top 8 cells, i.e., top 8 pairs of equivalent concepts
    List flagRow = new ArrayList(); // a list of row indexes to record the cells already chosen
    List flagCol = new ArrayList(); // a list of column indexes to record the cells already chosen
    double maxValue; // the maximum value in the matrix not chosen yet
    int maxRow, maxCol; // the corresponding indexes
//li
    //for(int i = 1; i <= 24; i ++){
    for(int i = 1; i <= 1232; i ++){
      maxValue = 0;
      maxRow = 1;
      maxCol = 1;
      //for (row = 1; row <= 24; row++) {
          //for (col = 1; col <= 24; col++) {
      for (row = 1; row <= 1232; row++) {
        for (col = 1; col <= 1232; col++) {
          if (simMatrix[row][col] >= maxValue && !flagRow.contains(row + "") && !flagCol.contains(col + "")) {
            maxRow = row;
            maxCol = col;
            maxValue = simMatrix[maxRow][maxCol];
          }
        }
      }

      if(!flagRow.contains(maxRow + "")) flagRow.add(maxRow + "");
      if(!flagCol.contains(maxCol + "")) flagCol.add(maxCol + "");

      System.out.println("Row: " + maxRow);
      System.out.println("Col: " + maxCol);
      System.out.println("maximum value: " + maxValue);
    }
  }

  public List getSimilarity(int i, int j){
    List sim = new ArrayList();
    String sValue = new String();
    String tmp1 = new String();
    String tmp2 = new String();
    String tmp3 = new String();
    String tmp4 = new String();
    String tmp5 = new String();
    String tmp6 = new String();
    int ind;
    //System.out.println(i);
    //System.out.println(j);
    //sValue = ( (String) simVecMatrix[i][j]).trim();
    //System.out.println(simVecMatrix[i][j]);

    //sValue = ( (String) simVecMatrix[i][j]).trim();
    sValue = ( (String) simVecMatrix[i][j]).trim();
    ind = sValue.indexOf("#");
    tmp1 = sValue.substring(0, ind);
    sValue = sValue.substring(ind + 1);
    
    ind = sValue.indexOf("#");
    tmp2 = sValue.substring(0, ind);
    sValue = sValue.substring(ind + 1);

    ind = sValue.indexOf("#");
    tmp3 = sValue.substring(0, ind);
    sValue = sValue.substring(ind + 1);

    ind = sValue.indexOf("#");
    tmp4 = sValue.substring(0, ind);
    sValue = sValue.substring(ind + 1);

    ind = sValue.indexOf("#");
    tmp5 = sValue.substring(0, ind);
    
    tmp6 = sValue.substring(ind + 1);
    
    /*
    System.out.println("tmp1:"+tmp1);
    System.out.println("tmp2:"+tmp2);
    System.out.println("tmp3:"+tmp3);
    System.out.println("tmp4:"+tmp4);
    System.out.println("tmp5:"+tmp5);
    System.out.println("tmp6:"+tmp6);
    */
    ou++;
    System.out.println(ou);
    
    sim.add(new Double(tmp1));
    sim.add(new Double(tmp2));
    sim.add(new Double(tmp3));
    sim.add(new Double(tmp4));
    sim.add(new Double(tmp5));
    sim.add(new Double(tmp6));

    return sim;
  }


  public void initSimMatrix(){
	    simVecMatrix = new String[1233][1233];
	    
	    CDEParser12321232runnableBackup cdeparser = new CDEParser12321232runnableBackup();
	    //deltarule.setSimVecMatrix(matrix);
		
	    System.out.println("Started");
	    //CDEParser CDEAANN;
	    CDEParser12321232runnableBackup.outputCurrentTime("1. Start parsing xml files --- ");
	    CDEParser12321232runnableBackup.getXmlFiles();
	    if(CDEParser12321232runnableBackup.XMLFiles.isEmpty())
	    {
	    	System.err.println("No XML Files located" );
	    }
	    for(String s: CDEParser12321232runnableBackup.XMLFiles)
	    {
	    	System.out.println("the xml files are: "+ s);
	    	String file_Name= new String(s);
	    	CDEParser12321232runnableBackup.outputCurrentTime("Now parsing file:: "+file_Name);
	    	CDEParser12321232runnableBackup.generateXML(file_Name);
	    }
	    
	    CDEParser12321232runnableBackup.BridgList();
	    
	    for(String s1:CDEParser12321232runnableBackup.bridgList.keySet())
	    {
	    	System.out.println("BRIDG_Class::"+s1+"-->COUNT::"+CDEParser12321232runnableBackup.bridgList.get(s1).size());
	    }
	    
	    System.out.println("TOTAL BRIDGS--->"+CDEParser12321232runnableBackup.bridgList.size());
	    
	    int count=0;
	    
	    for(String s:CDEParser12321232runnableBackup.bridgList.keySet())
	    {
	    	if(CDEParser12321232runnableBackup.bridgList.get(s).size()>=10)
	    	{
	    		count++;
	    	}
	    }
	    System.out.println("BRIDGS with only 1 result===>"+count);

	    
	    //li sCDESimMatrix get Similarity
	    double s1,s2,s3,s4,s5,s6;
	    double d1,d2,d3,d4,d5,d6;
	    double l1,l2,l3,l4,l5,l6;
	    
	    //��һ�е�i��Ԫ�غ͵�һ�е�j��Ԫ��
	    
	    for(int i = 1; i <= 1232; i = i+1) {
	    	for(int j = 1; j <= 1232; j = j+1) {
	    		
			    d1=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[1][i],CDEParser12321232runnableBackup.CDEMatrix[1][j]);
			    d2=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[2][i],CDEParser12321232runnableBackup.CDEMatrix[2][j]);
			    d3=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[3][i],CDEParser12321232runnableBackup.CDEMatrix[3][j]);
			    d4=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[4][i],CDEParser12321232runnableBackup.CDEMatrix[4][j]);
			    d5=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[5][i],CDEParser12321232runnableBackup.CDEMatrix[5][j]);
			    d6=CDEParser12321232runnableBackup.StringEditDistance.getDistance(CDEParser12321232runnableBackup.CDEMatrix[6][i],CDEParser12321232runnableBackup.CDEMatrix[6][j]);
			    //l1=CDEMatrix[6][i]��CDEMatrix[6][j])�����ַ����ĳ���
			    l1=(CDEParser12321232runnableBackup.CDEMatrix[1][i].length()>CDEParser12321232runnableBackup.CDEMatrix[1][j].length())?CDEParser12321232runnableBackup.CDEMatrix[1][i].length():CDEParser12321232runnableBackup.CDEMatrix[1][j].length();
			    l2=(CDEParser12321232runnableBackup.CDEMatrix[2][i].length()>CDEParser12321232runnableBackup.CDEMatrix[2][j].length())?CDEParser12321232runnableBackup.CDEMatrix[2][i].length():CDEParser12321232runnableBackup.CDEMatrix[2][j].length();
			    l3=(CDEParser12321232runnableBackup.CDEMatrix[3][i].length()>CDEParser12321232runnableBackup.CDEMatrix[3][j].length())?CDEParser12321232runnableBackup.CDEMatrix[3][i].length():CDEParser12321232runnableBackup.CDEMatrix[3][j].length();
			    l4=(CDEParser12321232runnableBackup.CDEMatrix[4][i].length()>CDEParser12321232runnableBackup.CDEMatrix[4][j].length())?CDEParser12321232runnableBackup.CDEMatrix[4][i].length():CDEParser12321232runnableBackup.CDEMatrix[4][j].length();
			    l5=(CDEParser12321232runnableBackup.CDEMatrix[5][i].length()>CDEParser12321232runnableBackup.CDEMatrix[5][j].length())?CDEParser12321232runnableBackup.CDEMatrix[5][i].length():CDEParser12321232runnableBackup.CDEMatrix[5][j].length();
			    l6=(CDEParser12321232runnableBackup.CDEMatrix[6][i].length()>CDEParser12321232runnableBackup.CDEMatrix[6][j].length())?CDEParser12321232runnableBackup.CDEMatrix[6][i].length():CDEParser12321232runnableBackup.CDEMatrix[6][j].length();

			    s1=CDEParser12321232runnableBackup.CDEMatrix[1][i].equals(CDEParser12321232runnableBackup.CDEMatrix[1][j])?1:(1-d1/l1);
			    s2=CDEParser12321232runnableBackup.CDEMatrix[2][i].equals(CDEParser12321232runnableBackup.CDEMatrix[2][j])?1:(1-d2/l2);
			    s3=CDEParser12321232runnableBackup.CDEMatrix[3][i].equals(CDEParser12321232runnableBackup.CDEMatrix[3][j])?1:(1-d3/l3);
			    s4=CDEParser12321232runnableBackup.CDEMatrix[4][i].equals(CDEParser12321232runnableBackup.CDEMatrix[4][j])?1:(1-d4/l4);
			    s5=CDEParser12321232runnableBackup.CDEMatrix[5][i].equals(CDEParser12321232runnableBackup.CDEMatrix[5][j])?1:(1-d5/l5);
			    s6=CDEParser12321232runnableBackup.CDEMatrix[6][i].equals(CDEParser12321232runnableBackup.CDEMatrix[6][j])?1:(1-d6/l6);
			    
			    DecimalFormat df = new DecimalFormat("0.00");
			    s1=Double.parseDouble(df.format(s1));
			    s2=Double.parseDouble(df.format(s2));
			    s3=Double.parseDouble(df.format(s3));
			    s4=Double.parseDouble(df.format(s4));
			    s5=Double.parseDouble(df.format(s5));
			    s6=Double.parseDouble(df.format(s6));
			    
			    CDEParser12321232runnableBackup.CDESimMatrix[i][j]=(s1+"#"+s2+"#"+s3+"#"+s4+"#"+s5+"#"+s6);
			    System.out.println(CDEParser12321232runnableBackup.CDESimMatrix[i][j]);
			    
			    simVecMatrix[i][j] = CDEParser12321232runnableBackup.CDESimMatrix[i][j];
	    	}
	    }
	    /**/
	    
	    //get training example
	    /*
	    for(int i = 1; i <= 1232; i = i+1) {
	    	for(int j = 1; j <= 1232; j = j+1) {
			    if(CDEMatrix[7][i].equals(CDEMatrix[7][j])) {
	    		System.out.println("trainingExamples"+"."+"add("+"\""+i+"@"+j+"\");");
			    }
	    	}
	    }
	    */
	    
	    //get training example no replicated
	    
	    for(int i = 1; i <= 1232; i = i+1) {
	    	for(int j = 1; j <= 1232; j = j+1) {
		    	if(i>j) {j=i;}
				    if(CDEParser12321232runnableBackup.CDEMatrix[7][i].equals(CDEParser12321232runnableBackup.CDEMatrix[7][j])) {
		    		//System.out.println("trainingExamples"+"."+"add("+"\""+i+"@"+j+"\");");
		    		trainingExamples.add(i+"@"+j);
				    }
		    	
	    	}
	    }
	    /**/
	  
  }

  



}
