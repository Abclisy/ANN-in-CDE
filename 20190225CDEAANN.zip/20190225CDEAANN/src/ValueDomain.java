
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="VALUEDOMAIN")
public class ValueDomain {

	private String Long_Name;
	private RepresentationTerm Representation_Term;
	

	/**
	 * @return the long_Name
	 */
	public String getLong_Name() {
		return Long_Name;
	}

	/**
	 * @param long_Name the long_Name to set
	 */
	@XmlElement(name="LongName")
	public void setLong_Name(String long_Name) {
		Long_Name = long_Name;
	}

	/**
	 * @return the representation_Term
	 */
	public RepresentationTerm getRepresentation_Term() {
		return Representation_Term;
	}

	/**
	 * @param representation_Term the representation_Term to set
	 */
	@XmlElement(name="Representation")
	public void setRepresentation_Term(RepresentationTerm representation_Term) {
		Representation_Term = representation_Term;
	}
}
