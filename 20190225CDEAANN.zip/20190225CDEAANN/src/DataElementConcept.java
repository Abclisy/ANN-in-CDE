
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="DATAELEMENTCONCEPT")
public class DataElementConcept {
	private String concept_ID;
	private String Long_Name;
	private Object_Class my_objclass;
	private property my_prop;
	
	
	
	/**
	 * @return the long_Name
	 */
	public String getLong_Name() {
		return Long_Name;
	}

	/**
	 * @param long_Name the long_Name to set
	 */
	@XmlElement(name="LongName")
	public void setLong_Name(String long_Name) {
		this.Long_Name = long_Name;
	}

	/**
	 * @return the my_prop
	 */
	public property getMy_prop() {
		return my_prop;
	}

	/**
	 * @param my_prop the my_prop to set
	 */
	@XmlElement(name="Property")
	public void setMy_prop(property my_prop) {
		this.my_prop = my_prop;
	}

	/**
	 * @return the my_objclass
	 */
	public Object_Class getMy_objclass() {
		return my_objclass;
	}

	/**
	 * @param my_objclass the my_objclass to set
	 */
	@XmlElement(name="ObjectClass")
	public void setMy_objclass(Object_Class my_objclass) {
		this.my_objclass = my_objclass;
	}

	/**
	 * @return the concept_ID
	 */
	public String getConcept_ID() {
		return concept_ID;
	}

	/**
	 * @param concept_ID the concept_ID to set
	 */
	@XmlElement(name="PublicId")
	public void setConcept_ID(String concept) {
		concept_ID = concept;
	}

	
}
