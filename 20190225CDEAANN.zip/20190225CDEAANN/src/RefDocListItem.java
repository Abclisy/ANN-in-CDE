
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="REFERENCEDOCUMENTSLIST_ITEM")
public class RefDocListItem {
	private String r_Name;
	private String doc_type;
	private String doc_Text;
	private static String BRIDG_Path;
	private static boolean is_pref;
	private static boolean is_bridgMap;
	
	/**
	 * @return the r_Name
	 */
	public String getR_Name() {
		return r_Name;
	}
	/**
	 * @param r_Name the r_Name to set
	 */
	@XmlElement(name="LongName")
	public void setR_Name(String Name) {
		r_Name = Name;
	}
	/**
	 * @return the doc_type
	 */
	public String getDoc_type() {
		return doc_type;
	}
	/**
	 * @param doc_type the doc_type to set
	 */
	@XmlElement(name="DocumentType")
	public void setDoc_type(String type) {
		doc_type = type;
	}
	/**
	 * @return the doc_Text
	 */
	public String getDoc_Text() {
		return doc_Text;
	}
	/**
	 * @param doc_Text the doc_Text to set
	 */
	@XmlElement(name="DocumentText")
	public void setDoc_Text(String Text) {
		doc_Text = Text;
	}
	/**
	 * @return the is_pref
	 */
	public static boolean isIs_pref() {
		return is_pref;
	}
	/**
	 * @param is_pref the is_pref to set
	 */
	public static void setIs_pref(boolean pref) {
		is_pref = pref;
	}
	/**
	 * @return the is_bridgMap
	 */
	public static boolean isIs_bridgMap() {
		return is_bridgMap;
	}
	/**
	 * @param is_bridgMap the is_bridgMap to set
	 */
	public static void setIs_bridgMap(boolean bridgMap) {
		is_bridgMap = bridgMap;
	}
	/**
	 * @return the bRIDG_Path
	 */
	public static String getBRIDG_Path() {
		return BRIDG_Path;
	}
	/**
	 * @param bRIDG_Path the bRIDG_Path to set
	 */
	public static void setBRIDG_Path(String bRIDG_Path) {
		BRIDG_Path = bRIDG_Path;
	}

}
