
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ALTERNATENAMELIST_ITEM")
public class AlterListItem {
	private String Alt_name;
	private String Alt_type;
	private static boolean HCT_Type;
	private static String BRIDG_class;
	private static String BRIDG_Attr;
	
	/**
	 * @return the hCT_Type
	 */
	public static boolean isHCT_Type() {
		return HCT_Type;
	}

	/**
	 * @param hCT_Type the hCT_Type to set
	 */
	public static void setHCT_Type(boolean Type) {
		HCT_Type = Type;
	}

	/**
	 * @return the bRIDG_class
	 */
	public static String getBRIDG_class() {
		return BRIDG_class;
	}

	/**
	 * @param bRIDG_class the bRIDG_class to set
	 */
	public void setBRIDG_class(String bRIDG_class) {
		BRIDG_class = bRIDG_class;
	}

	/**
	 * @return the bRIDG_Attr
	 */
	public static String getBRIDG_Attr() {
		return BRIDG_Attr;
	}

	/**
	 * @param bRIDG_Attr the bRIDG_Attr to set
	 */
	public static void setBRIDG_Attr(String bRIDG_Attr) {
		BRIDG_Attr = bRIDG_Attr;
	}

	/**
	 * @return the alt_type
	 */
	public String getAlt_type() {
		return Alt_type;
	}

	/**
	 * @param alt_type the alt_type to set
	 */
	@XmlElement(name="AlternateNameType")
	public void setAlt_type(String type) {
		Alt_type = type;
	}

	/**
	 * @return the alt_name
	 */
	public String getAlt_name() {
		return Alt_name;
	}

	/**
	 * @param alt_name the alt_name to set
	 */
	@XmlElement(name="AlternateName")
	public void setAlt_name(String alt_name) {
		Alt_name = alt_name;
	}

	

}
